﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AD_W04_Take_Home_Soccer_Players
{
    public partial class Form1 : Form
    {
        List<Team> teams;
        List<string> countriesList;


        public Form1()
        {
            InitializeComponent();

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Player> player1 = new List<Player> 
            {
                new Player("David De Gea", "01", "GK"),
                new Player("Victor Lindelof", "02", "DF"),
                new Player("Phil Jones", "04", "DF"),
                new Player("Harry Maguire", "05", "DF"),
                new Player("Lisandro Martinez", "06", "DF"),
                new Player("Bruno Fernandez", "08", "MF"),
                new Player("Anthony Martial", "09", "FW"),
                new Player("Marcus Rashford", "10", "FW"),
                new Player("Tyrell Malacia", "12", "DF"),
                new Player("Christian Eriksen", "14", "MF"),
                new Player("Casemiro", "18", "MF")
            };

            List<Player> player2 = new List<Player> 
            {
                new Player("Kepa Amizabalaga", "01", "GK"),
                new Player("Benoît Badiashile", "04", "DF"),
                new Player("Enzo Fernández", "05", "MF"),
                new Player("Thiago Silva", "06", "DF"),
                new Player("N'Golo Kanté", "07", "MF"),
                new Player("Mateo Kovačić", "08", "MF"),
                new Player("Pierre-Emerick Aubameyang", "09", "FW"),
                new Player("Christian Pulisic", "10", "MF"),
                new Player("João Félix", "11", "FW"),
                new Player("Ruben Loftus-Cheek", "12", "MF"),
                new Player("Raheem Sterling", "17", "MF")
            };

            List<Player> player3 = new List<Player> 
            {
                new Player("Manuel Neuer", "01", "GK"),
                new Player("Dayot Upamecano", "02", "DF"),
                new Player("Matthijs de Ligt", "04", "GK"),
                new Player("Benjamin Pavard", "05", "GK"),
                new Player("Joshua Kimmich", "06", "MF"),
                new Player("Serge Gnabry", "07", "FW"),
                new Player("Leon Goretzka", "08", "MF"),
                new Player("Leroy Sané", "10", "FW"),
                new Player("Paul Wanner", "14", "MF"),
                new Player("Lucas Hernandez", "21", "DF"),
                new Player("Thomas Müller", "25", "FW")
            };

            Team team1 = new Team("Manchester United", "England", "Manchester", player1);
            Team team2 = new Team("Chelsea", "England", "Chelsea", player2);
            Team team3 = new Team("Bayern Munich", "Germany", "Munich", player3);

            teams = new List<Team> { team1, team2, team3 };
            countriesList = new List<string> { "England", "Germany" };
            cBox_chooseCountry.DataSource = countriesList;

            // Clear
            cBox_chooseCountry.SelectedIndex = -1;
            cBox_chooseTeam.SelectedIndex = -1;
            lBox_playerList.Items.Clear();
        }

        private void btn_addTeam_Click(object sender, EventArgs e)
        {
            bool canAddTeam = true;

            if (tb_teamName.Text == "" || tb_teamCountry.Text == "" || tb_teamCity.Text == "")
            {
                canAddTeam = false;
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (canAddTeam == true)
            {
                foreach (Team s in teams)
                {
                    if (s.TeamName == tb_teamName.Text)
                    {
                        canAddTeam = false;
                        break;
                    }
                }

                if (canAddTeam == false)
                {
                    MessageBox.Show("Team Name Already Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            if (canAddTeam == true)
            {
                Team newTeam = new Team(tb_teamName.Text, tb_teamCountry.Text, tb_teamCity.Text, new List<Player>());
                teams.Add(newTeam);
                cBox_chooseCountry.SelectedIndex = -1;

                if (countriesList.Contains(tb_teamCountry.Text) == false)
                {
                    countriesList.Add(tb_teamCountry.Text);
                    cBox_chooseCountry.DataSource = null;
                    cBox_chooseCountry.DataSource = countriesList;
                }
                tb_teamName.Text = "";
                tb_teamCountry.Text = "";
                tb_teamCity.Text = "";
            }

        }

        private void btn_addPlayer_Click(object sender, EventArgs e)
        {
            bool canAddPlayer = true;

            if (tb_playerName.Text == "" || tb_playerNumber.Text == "" || cBox_playerPosition.SelectedItem == null)
            {
                canAddPlayer = false;
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (canAddPlayer == true)
            {
                Team selectedTeam = (Team)cBox_chooseTeam.SelectedItem;
                string playerPos = (string)cBox_playerPosition.SelectedItem;
                Player newPlayer = new Player(tb_playerName.Text, tb_playerNumber.Text, playerPos);

                foreach (Player p in selectedTeam.Players)
                {
                    if (p.PlayerName == tb_playerName.Text)
                    {
                        canAddPlayer = false;
                        break;
                    }

                }
                if (canAddPlayer == false)
                {
                    MessageBox.Show("Player with the same Name Already Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }

            if (canAddPlayer == true)
            {
                Team selectedTeam = (Team)cBox_chooseTeam.SelectedItem;
                string playerPos = (string)cBox_playerPosition.SelectedItem;
                Player newPlayer = new Player(tb_playerName.Text, tb_playerNumber.Text, playerPos);

                foreach (Player p in selectedTeam.Players)
                {
                    if (p.PlayerNum == tb_playerNumber.Text)
                    {
                        canAddPlayer = false;
                        break;
                    }

                }
                if (canAddPlayer == false)
                {
                    MessageBox.Show("Player with the same Number Already Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }

            if (canAddPlayer == true)
            {
                Team selectedTeam = (Team)cBox_chooseTeam.SelectedItem;
                string playerPos = (string)cBox_playerPosition.SelectedItem;
                Player newPlayer = new Player(tb_playerName.Text, tb_playerNumber.Text, playerPos);

                selectedTeam.Players.Add(newPlayer);
                lBox_playerList.Items.Clear();
                foreach (Player p in selectedTeam.Players)
                {
                    lBox_playerList.Items.Add("(" + p.PlayerNum + ") " + p.PlayerName + ", " + p.PlayerPos);
                }
                tb_playerName.Text = "";
                tb_playerNumber.Text = "";
                cBox_playerPosition.SelectedIndex = -1;


            }


        }

        private void cBox_chooseCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCountry = (string)cBox_chooseCountry.SelectedItem;
            List<Team> choosenTeam = new List<Team>();
            foreach (Team s in teams)
            {
                if (s.TeamCountry == selectedCountry)
                {
                    choosenTeam.Add(s);
                }
            }
            cBox_chooseTeam.DataSource = choosenTeam;
            cBox_chooseTeam.DisplayMember = "TeamName"; 


        }

        private void cBox_chooseTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            lBox_playerList.Items.Clear();
            Team selectedTeam = (Team)cBox_chooseTeam.SelectedItem;
            if (selectedTeam.Players != null)
            {
                foreach (Player p in selectedTeam.Players)
                {
                    lBox_playerList.Items.Add("(" + p.PlayerNum + ") " + p.PlayerName + ", " + p.PlayerPos);
                }
            }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            int indexHapus = lBox_playerList.SelectedIndex;
            Team selectedTeam = (Team)cBox_chooseTeam.SelectedItem;
            if (selectedTeam.Players.Count > 11)
            {
                selectedTeam.Players.RemoveAt(indexHapus);
                lBox_playerList.Items.Clear();
                foreach (Player p in selectedTeam.Players)
                {
                    lBox_playerList.Items.Add("(" + p.PlayerNum + ") " + p.PlayerName + ", " + p.PlayerPos);
                }
            }
            else
            {
                MessageBox.Show("Unable to Remove Players if Players less than equal 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
