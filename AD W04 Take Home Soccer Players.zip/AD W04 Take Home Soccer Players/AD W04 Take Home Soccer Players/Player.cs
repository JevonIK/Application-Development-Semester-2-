﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AD_W04_Take_Home_Soccer_Players
{
    internal class Player
    {
        private string playerName;
        private string playerNum;
        private string playerPos;

        public Player(string playerName, string playerNum, string playerPos)
        {
            this.playerName = playerName;
            this.playerNum = playerNum;
            this.playerPos = playerPos;
        }

        public string PlayerName { get => playerName; set => playerName = value; }
        public string PlayerNum { get => playerNum; set => playerNum = value; }
        public string PlayerPos { get => playerPos; set => playerPos = value; }
    }
}
