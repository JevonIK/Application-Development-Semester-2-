﻿namespace AD_W04_Take_Home_Soccer_Players
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_stl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cBox_chooseCountry = new System.Windows.Forms.ComboBox();
            this.cBox_chooseTeam = new System.Windows.Forms.ComboBox();
            this.lBox_playerList = new System.Windows.Forms.ListBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_teamName = new System.Windows.Forms.TextBox();
            this.tb_teamCountry = new System.Windows.Forms.TextBox();
            this.tb_teamCity = new System.Windows.Forms.TextBox();
            this.btn_addTeam = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_addPlayer = new System.Windows.Forms.Button();
            this.tb_playerNumber = new System.Windows.Forms.TextBox();
            this.tb_playerName = new System.Windows.Forms.TextBox();
            this.cBox_playerPosition = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lb_stl
            // 
            this.lb_stl.AutoSize = true;
            this.lb_stl.Location = new System.Drawing.Point(101, 43);
            this.lb_stl.Name = "lb_stl";
            this.lb_stl.Size = new System.Drawing.Size(112, 16);
            this.lb_stl.TabIndex = 0;
            this.lb_stl.Text = "Soccer Team List";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Choose Country:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Choose Team:";
            // 
            // cBox_chooseCountry
            // 
            this.cBox_chooseCountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_chooseCountry.FormattingEnabled = true;
            this.cBox_chooseCountry.Items.AddRange(new object[] {
            "England",
            "Germany"});
            this.cBox_chooseCountry.Location = new System.Drawing.Point(160, 85);
            this.cBox_chooseCountry.Name = "cBox_chooseCountry";
            this.cBox_chooseCountry.Size = new System.Drawing.Size(169, 24);
            this.cBox_chooseCountry.TabIndex = 3;
            this.cBox_chooseCountry.SelectedIndexChanged += new System.EventHandler(this.cBox_chooseCountry_SelectedIndexChanged);
            // 
            // cBox_chooseTeam
            // 
            this.cBox_chooseTeam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_chooseTeam.FormattingEnabled = true;
            this.cBox_chooseTeam.Location = new System.Drawing.Point(160, 126);
            this.cBox_chooseTeam.Name = "cBox_chooseTeam";
            this.cBox_chooseTeam.Size = new System.Drawing.Size(169, 24);
            this.cBox_chooseTeam.TabIndex = 4;
            this.cBox_chooseTeam.SelectedIndexChanged += new System.EventHandler(this.cBox_chooseTeam_SelectedIndexChanged);
            // 
            // lBox_playerList
            // 
            this.lBox_playerList.FormattingEnabled = true;
            this.lBox_playerList.ItemHeight = 16;
            this.lBox_playerList.Location = new System.Drawing.Point(51, 175);
            this.lBox_playerList.Name = "lBox_playerList";
            this.lBox_playerList.Size = new System.Drawing.Size(278, 132);
            this.lBox_playerList.TabIndex = 5;
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(51, 323);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(75, 23);
            this.btn_remove.TabIndex = 6;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(404, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Adding Team";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(356, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Team Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(356, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Team Country:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(356, 172);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Team City:";
            // 
            // tb_teamName
            // 
            this.tb_teamName.Location = new System.Drawing.Point(460, 85);
            this.tb_teamName.Name = "tb_teamName";
            this.tb_teamName.Size = new System.Drawing.Size(116, 22);
            this.tb_teamName.TabIndex = 11;
            // 
            // tb_teamCountry
            // 
            this.tb_teamCountry.Location = new System.Drawing.Point(460, 126);
            this.tb_teamCountry.Name = "tb_teamCountry";
            this.tb_teamCountry.Size = new System.Drawing.Size(116, 22);
            this.tb_teamCountry.TabIndex = 12;
            // 
            // tb_teamCity
            // 
            this.tb_teamCity.Location = new System.Drawing.Point(460, 169);
            this.tb_teamCity.Name = "tb_teamCity";
            this.tb_teamCity.Size = new System.Drawing.Size(116, 22);
            this.tb_teamCity.TabIndex = 13;
            // 
            // btn_addTeam
            // 
            this.btn_addTeam.Location = new System.Drawing.Point(460, 218);
            this.btn_addTeam.Name = "btn_addTeam";
            this.btn_addTeam.Size = new System.Drawing.Size(75, 23);
            this.btn_addTeam.TabIndex = 14;
            this.btn_addTeam.Text = "Add";
            this.btn_addTeam.UseVisualStyleBackColor = true;
            this.btn_addTeam.Click += new System.EventHandler(this.btn_addTeam_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(688, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "Adding Players";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(642, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 16);
            this.label8.TabIndex = 16;
            this.label8.Text = "Player Name:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(642, 126);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 16);
            this.label9.TabIndex = 17;
            this.label9.Text = "Player Number:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(642, 172);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 16);
            this.label10.TabIndex = 18;
            this.label10.Text = "Player Position:";
            // 
            // btn_addPlayer
            // 
            this.btn_addPlayer.Location = new System.Drawing.Point(747, 217);
            this.btn_addPlayer.Name = "btn_addPlayer";
            this.btn_addPlayer.Size = new System.Drawing.Size(75, 23);
            this.btn_addPlayer.TabIndex = 19;
            this.btn_addPlayer.Text = "Add";
            this.btn_addPlayer.UseVisualStyleBackColor = true;
            this.btn_addPlayer.Click += new System.EventHandler(this.btn_addPlayer_Click);
            // 
            // tb_playerNumber
            // 
            this.tb_playerNumber.Location = new System.Drawing.Point(756, 126);
            this.tb_playerNumber.Name = "tb_playerNumber";
            this.tb_playerNumber.Size = new System.Drawing.Size(116, 22);
            this.tb_playerNumber.TabIndex = 21;
            // 
            // tb_playerName
            // 
            this.tb_playerName.Location = new System.Drawing.Point(756, 85);
            this.tb_playerName.Name = "tb_playerName";
            this.tb_playerName.Size = new System.Drawing.Size(116, 22);
            this.tb_playerName.TabIndex = 20;
            // 
            // cBox_playerPosition
            // 
            this.cBox_playerPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_playerPosition.FormattingEnabled = true;
            this.cBox_playerPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cBox_playerPosition.Location = new System.Drawing.Point(756, 167);
            this.cBox_playerPosition.Name = "cBox_playerPosition";
            this.cBox_playerPosition.Size = new System.Drawing.Size(116, 24);
            this.cBox_playerPosition.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(935, 483);
            this.Controls.Add(this.cBox_playerPosition);
            this.Controls.Add(this.tb_playerNumber);
            this.Controls.Add(this.tb_playerName);
            this.Controls.Add(this.btn_addPlayer);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_addTeam);
            this.Controls.Add(this.tb_teamCity);
            this.Controls.Add(this.tb_teamCountry);
            this.Controls.Add(this.tb_teamName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.lBox_playerList);
            this.Controls.Add(this.cBox_chooseTeam);
            this.Controls.Add(this.cBox_chooseCountry);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_stl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_stl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cBox_chooseCountry;
        private System.Windows.Forms.ComboBox cBox_chooseTeam;
        private System.Windows.Forms.ListBox lBox_playerList;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_teamName;
        private System.Windows.Forms.TextBox tb_teamCountry;
        private System.Windows.Forms.TextBox tb_teamCity;
        private System.Windows.Forms.Button btn_addTeam;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_addPlayer;
        private System.Windows.Forms.TextBox tb_playerNumber;
        private System.Windows.Forms.TextBox tb_playerName;
        private System.Windows.Forms.ComboBox cBox_playerPosition;
    }
}

