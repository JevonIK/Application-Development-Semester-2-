﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AD_W08_Take_Home_Clothing_Shop
{
    public partial class Form_uniqme : Form
    {
        // Jevon Ivander K (0706022310028) (week 09)
        int hargaProduk1;
        int hargaProduk2;
        int hargaProduk3;

        DataTable dt = new DataTable();

        int indexBarisan = -1;
        public Form_uniqme()
        {
            InitializeComponent();
        }

        private void Form_uniqme_Load(object sender, EventArgs e)
        {
            panel_pertama.Visible = false;
            panel_kedua.Visible = false;

            dt.Columns.Add("Item Name");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Price");
            dt.Columns.Add("Total");

            btn_add4.Enabled = false;
            tb_itemName.Enabled = false;
            tb_itemPrice.Enabled = false;


        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pertama.Visible = true;
            panel_kedua.Visible = false;

            pBox_1.Image = Properties.Resources.T_Shirt1_KerahBulat;
            pBox_2.Image = Properties.Resources.T_Shirt2_Airism;
            pBox_3.Image = Properties.Resources.T_Shirt3_VNeck;

            lb_namaProduk1.Text = "T-Shirt Kerah Bulat";
            lb_namaProduk2.Text = "AIRISM T-Shirt";
            lb_namaProduk3.Text = "T-Shirt V Neck";

            hargaProduk1 = 150000;
            hargaProduk2 = 250000;
            hargaProduk3 = 125000;
            lb_hargaProduk1.Text = "Rp. " + hargaProduk1.ToString("#,0.") + ".-";
            lb_hargaProduk2.Text = "Rp. " + hargaProduk2.ToString("#,0.") + ".-";
            lb_hargaProduk3.Text = "Rp. " + hargaProduk3.ToString("#,0.") + ".-";

        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pertama.Visible = true;
            panel_kedua.Visible = false;

            pBox_1.Image = Properties.Resources.Shirt1_PremiumCasual;
            pBox_2.Image = Properties.Resources.Shirt2_DarkBlue;
            pBox_3.Image = Properties.Resources.Shirt3_White;

            lb_namaProduk1.Text = "Premium Casual Shirt";
            lb_namaProduk2.Text = "Dark Blue Shirt";
            lb_namaProduk3.Text = "White Standard Shirt";

            hargaProduk1 = 550000;
            hargaProduk2 = 500000;
            hargaProduk3 = 350000;
            lb_hargaProduk1.Text = "Rp. " + hargaProduk1.ToString("#,0.") + ".-";
            lb_hargaProduk2.Text = "Rp. " + hargaProduk2.ToString("#,0.") + ".-";
            lb_hargaProduk3.Text = "Rp. " + hargaProduk3.ToString("#,0.") + ".-";
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pertama.Visible = true;
            panel_kedua.Visible = false;

            pBox_1.Image = Properties.Resources.Pants1_BlackShort;
            pBox_2.Image = Properties.Resources.Pants2_CargoShort;
            pBox_3.Image = Properties.Resources.Pants3_NavyShort;

            lb_namaProduk1.Text = "Black Short Pants";
            lb_namaProduk2.Text = "Cargo Short Pants";
            lb_namaProduk3.Text = "Navy Short Pants";

            hargaProduk1 = 265000;
            hargaProduk2 = 280000;
            hargaProduk3 = 250000;
            lb_hargaProduk1.Text = "Rp. " + hargaProduk1.ToString("#,0.") + ".-";
            lb_hargaProduk2.Text = "Rp. " + hargaProduk2.ToString("#,0.") + ".-";
            lb_hargaProduk3.Text = "Rp. " + hargaProduk3.ToString("#,0.") + ".-";
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pertama.Visible = true;
            panel_kedua.Visible = false;

            pBox_1.Image = Properties.Resources.LongPants1_Camo;
            pBox_2.Image = Properties.Resources.LongPants2_Cargo;
            pBox_3.Image = Properties.Resources.LongPants3_Jeans;

            lb_namaProduk1.Text = "Camo Long Pants";
            lb_namaProduk2.Text = "Cargo Long Pants";
            lb_namaProduk3.Text = "Jeans Long Pants";

            hargaProduk1 = 600000;
            hargaProduk2 = 650000;
            hargaProduk3 = 780000;
            lb_hargaProduk1.Text = "Rp. " + hargaProduk1.ToString("#,0.") + ".-";
            lb_hargaProduk2.Text = "Rp. " + hargaProduk2.ToString("#,0.") + ".-";
            lb_hargaProduk3.Text = "Rp. " + hargaProduk3.ToString("#,0.") + ".-";
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pertama.Visible = true;
            panel_kedua.Visible = false;

            pBox_1.Image = Properties.Resources.Shoes1_Airforce;
            pBox_2.Image = Properties.Resources.Shoes2_Jordan;
            pBox_3.Image = Properties.Resources.Shoes3_NewBalance;

            lb_namaProduk1.Text = "Airforce 1 Shoes";
            lb_namaProduk2.Text = "Jordan Shoes";
            lb_namaProduk3.Text = "New Balance Shoes";

            hargaProduk1 = 1800000;
            hargaProduk2 = 3000000;
            hargaProduk3 = 2500000;
            lb_hargaProduk1.Text = "Rp. " + hargaProduk1.ToString("#,0.") + ".-";
            lb_hargaProduk2.Text = "Rp. " + hargaProduk2.ToString("#,0.") + ".-";
            lb_hargaProduk3.Text = "Rp. " + hargaProduk3.ToString("#,0.") + ".-";
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pertama.Visible = true;
            panel_kedua.Visible = false;

            pBox_1.Image = Properties.Resources.Jewelleries1_GoldEarrings;
            pBox_2.Image = Properties.Resources.Jewelleries2_RoseGoldRings;
            pBox_3.Image = Properties.Resources.Jewelleries3_Necklace;

            lb_namaProduk1.Text = "Gold Earrings";
            lb_namaProduk2.Text = "Rose Gold Rings";
            lb_namaProduk3.Text = "Necklace";

            hargaProduk1 = 5000000;
            hargaProduk2 = 10000000;
            hargaProduk3 = 8000000;
            lb_hargaProduk1.Text = "Rp. " + hargaProduk1.ToString("#,0.") + ".-";
            lb_hargaProduk2.Text = "Rp. " + hargaProduk2.ToString("#,0.") + ".-";
            lb_hargaProduk3.Text = "Rp. " + hargaProduk3.ToString("#,0.") + ".-";
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pertama.Visible = false;
            panel_kedua.Visible = true;
        }

        private void btn_add1_Click(object sender, EventArgs e)
        {
            AddProduct(lb_namaProduk1.Text, hargaProduk1);
            dgv_shoppingList.DataSource = dt;
        }

        private void btn_add2_Click(object sender, EventArgs e)
        {         
            AddProduct(lb_namaProduk2.Text, hargaProduk2);
            dgv_shoppingList.DataSource = dt;
        }

        private void btn_add3_Click(object sender, EventArgs e)
        {         
            AddProduct(lb_namaProduk3.Text, hargaProduk3);
            dgv_shoppingList.DataSource = dt;
        }

        private void AddProduct(string labelNama, int labelPrice)
        {
            int qty;
            bool checkExist = false;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (labelNama == dt.Rows[i]["Item Name"].ToString())
                {
                    qty = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                    dt.Rows[i]["Quantity"] = qty;
                    dt.Rows[i]["Total"] = qty * labelPrice;

                    checkExist = true;
                    break;
                }
            }

            if (checkExist == false)
            {
                dt.Rows.Add(labelNama, 1, labelPrice, labelPrice);
            }
            dgv_shoppingList.DataSource = dt;

            //estetika kolom
            dgv_shoppingList.Columns[0].Width = 110;
            dgv_shoppingList.Columns[1].Width = 60;


            // menghitung subtotal dan total

            int subTotal = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                subTotal += Convert.ToInt32(dt.Rows[i]["Total"]);
            }
            tb_subTotal.Text = "Rp. " + subTotal.ToString("#,0.") + ".-";

            double total = subTotal + subTotal*0.1;
            tb_total.Text = "Rp. " + total.ToString("#,0.") + ".-";
        }

        private void dgv_shoppingList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexBarisan = e.RowIndex;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (indexBarisan >= 0 & dt.Rows.Count > 0)
            {
                dt.Rows.RemoveAt(indexBarisan);
                dgv_shoppingList.DataSource= dt;

                int subTotal = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dt.Rows[i]["Total"]);
                }
                tb_subTotal.Text = "Rp. " + subTotal.ToString("#,0.") + ".-";

                double total = subTotal + subTotal * 0.1;
                tb_total.Text = "Rp. " + total.ToString("#,0.") + ".-";
            }
        }

        private void tb_itemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.jpg, *.png, *.bmp)|*.jpg; *.png; *.bmp|All Files (.)|*.*";
            ofd.Multiselect = true;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pBox_4.Image = Image.FromFile(ofd.FileName);
                tb_itemName.Enabled = true;
                tb_itemPrice.Enabled = true;
            }
        }

        private void btn_add4_Click(object sender, EventArgs e)
        {
            if (tb_itemName.Text != "" && tb_itemPrice.Text != "")
            {
                AddProduct(tb_itemName.Text, Convert.ToInt32(tb_itemPrice.Text));
                dgv_shoppingList.DataSource = dt;
            }
            
        }

        private void tb_itemName_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemName.Text != "" && tb_itemPrice.Text != "")
            {
                btn_add4.Enabled = true;
            }
            else if (tb_itemName.Text == "" || tb_itemPrice.Text == "")
            {
                btn_add4.Enabled = false;
            }
        }

        private void tb_itemPrice_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemName.Text != "" && tb_itemPrice.Text != "")
            {
                btn_add4.Enabled = true;
            }
            else if (tb_itemName.Text == "" || tb_itemPrice.Text == "")
            {
                btn_add4.Enabled = false;
            }
        }
    }
}
