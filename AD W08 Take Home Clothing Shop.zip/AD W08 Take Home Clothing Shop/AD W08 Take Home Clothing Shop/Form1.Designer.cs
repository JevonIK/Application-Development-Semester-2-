﻿namespace AD_W08_Take_Home_Clothing_Shop
{
    partial class Form_uniqme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip_ClothShop = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_shoppingList = new System.Windows.Forms.DataGridView();
            this.lb_subtotal = new System.Windows.Forms.Label();
            this.lb_total = new System.Windows.Forms.Label();
            this.tb_subTotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.pBox_1 = new System.Windows.Forms.PictureBox();
            this.pBox_2 = new System.Windows.Forms.PictureBox();
            this.pBox_3 = new System.Windows.Forms.PictureBox();
            this.lb_namaProduk1 = new System.Windows.Forms.Label();
            this.lb_namaProduk2 = new System.Windows.Forms.Label();
            this.lb_namaProduk3 = new System.Windows.Forms.Label();
            this.lb_hargaProduk1 = new System.Windows.Forms.Label();
            this.lb_hargaProduk2 = new System.Windows.Forms.Label();
            this.lb_hargaProduk3 = new System.Windows.Forms.Label();
            this.btn_add1 = new System.Windows.Forms.Button();
            this.btn_add2 = new System.Windows.Forms.Button();
            this.btn_add3 = new System.Windows.Forms.Button();
            this.panel_pertama = new System.Windows.Forms.Panel();
            this.panel_kedua = new System.Windows.Forms.Panel();
            this.tb_itemPrice = new System.Windows.Forms.TextBox();
            this.tb_itemName = new System.Windows.Forms.TextBox();
            this.lb_itemPrice = new System.Windows.Forms.Label();
            this.lb_itemName = new System.Windows.Forms.Label();
            this.lb_uploadImage = new System.Windows.Forms.Label();
            this.btn_add4 = new System.Windows.Forms.Button();
            this.btn_upload = new System.Windows.Forms.Button();
            this.pBox_4 = new System.Windows.Forms.PictureBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.menuStrip_ClothShop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_shoppingList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_3)).BeginInit();
            this.panel_pertama.SuspendLayout();
            this.panel_kedua.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_4)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip_ClothShop
            // 
            this.menuStrip_ClothShop.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_ClothShop.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip_ClothShop.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_ClothShop.Name = "menuStrip_ClothShop";
            this.menuStrip_ClothShop.Size = new System.Drawing.Size(1132, 28);
            this.menuStrip_ClothShop.TabIndex = 0;
            this.menuStrip_ClothShop.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv_shoppingList
            // 
            this.dgv_shoppingList.AllowUserToAddRows = false;
            this.dgv_shoppingList.AllowUserToDeleteRows = false;
            this.dgv_shoppingList.AllowUserToResizeColumns = false;
            this.dgv_shoppingList.AllowUserToResizeRows = false;
            this.dgv_shoppingList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_shoppingList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_shoppingList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_shoppingList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_shoppingList.Location = new System.Drawing.Point(654, 69);
            this.dgv_shoppingList.Name = "dgv_shoppingList";
            this.dgv_shoppingList.RowHeadersVisible = false;
            this.dgv_shoppingList.RowHeadersWidth = 51;
            this.dgv_shoppingList.RowTemplate.Height = 24;
            this.dgv_shoppingList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_shoppingList.Size = new System.Drawing.Size(453, 318);
            this.dgv_shoppingList.TabIndex = 1;
            this.dgv_shoppingList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_shoppingList_CellClick);
            // 
            // lb_subtotal
            // 
            this.lb_subtotal.AutoSize = true;
            this.lb_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtotal.Location = new System.Drawing.Point(649, 412);
            this.lb_subtotal.Name = "lb_subtotal";
            this.lb_subtotal.Size = new System.Drawing.Size(115, 25);
            this.lb_subtotal.TabIndex = 2;
            this.lb_subtotal.Text = "Sub-Total:";
            // 
            // lb_total
            // 
            this.lb_total.AutoSize = true;
            this.lb_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total.Location = new System.Drawing.Point(696, 456);
            this.lb_total.Name = "lb_total";
            this.lb_total.Size = new System.Drawing.Size(68, 25);
            this.lb_total.TabIndex = 3;
            this.lb_total.Text = "Total:";
            // 
            // tb_subTotal
            // 
            this.tb_subTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_subTotal.Location = new System.Drawing.Point(783, 409);
            this.tb_subTotal.Name = "tb_subTotal";
            this.tb_subTotal.ReadOnly = true;
            this.tb_subTotal.Size = new System.Drawing.Size(307, 30);
            this.tb_subTotal.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_total.Location = new System.Drawing.Point(783, 453);
            this.tb_total.Name = "tb_total";
            this.tb_total.ReadOnly = true;
            this.tb_total.Size = new System.Drawing.Size(307, 30);
            this.tb_total.TabIndex = 5;
            // 
            // pBox_1
            // 
            this.pBox_1.Location = new System.Drawing.Point(15, 18);
            this.pBox_1.Name = "pBox_1";
            this.pBox_1.Size = new System.Drawing.Size(152, 233);
            this.pBox_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_1.TabIndex = 6;
            this.pBox_1.TabStop = false;
            // 
            // pBox_2
            // 
            this.pBox_2.Location = new System.Drawing.Point(221, 18);
            this.pBox_2.Name = "pBox_2";
            this.pBox_2.Size = new System.Drawing.Size(152, 233);
            this.pBox_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_2.TabIndex = 7;
            this.pBox_2.TabStop = false;
            // 
            // pBox_3
            // 
            this.pBox_3.Location = new System.Drawing.Point(405, 18);
            this.pBox_3.Name = "pBox_3";
            this.pBox_3.Size = new System.Drawing.Size(152, 233);
            this.pBox_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_3.TabIndex = 8;
            this.pBox_3.TabStop = false;
            // 
            // lb_namaProduk1
            // 
            this.lb_namaProduk1.AutoSize = true;
            this.lb_namaProduk1.Location = new System.Drawing.Point(12, 267);
            this.lb_namaProduk1.Name = "lb_namaProduk1";
            this.lb_namaProduk1.Size = new System.Drawing.Size(44, 16);
            this.lb_namaProduk1.TabIndex = 9;
            this.lb_namaProduk1.Text = "label1";
            // 
            // lb_namaProduk2
            // 
            this.lb_namaProduk2.AutoSize = true;
            this.lb_namaProduk2.Location = new System.Drawing.Point(218, 267);
            this.lb_namaProduk2.Name = "lb_namaProduk2";
            this.lb_namaProduk2.Size = new System.Drawing.Size(44, 16);
            this.lb_namaProduk2.TabIndex = 10;
            this.lb_namaProduk2.Text = "label1";
            // 
            // lb_namaProduk3
            // 
            this.lb_namaProduk3.AutoSize = true;
            this.lb_namaProduk3.Location = new System.Drawing.Point(402, 267);
            this.lb_namaProduk3.Name = "lb_namaProduk3";
            this.lb_namaProduk3.Size = new System.Drawing.Size(44, 16);
            this.lb_namaProduk3.TabIndex = 11;
            this.lb_namaProduk3.Text = "label1";
            // 
            // lb_hargaProduk1
            // 
            this.lb_hargaProduk1.AutoSize = true;
            this.lb_hargaProduk1.Location = new System.Drawing.Point(12, 296);
            this.lb_hargaProduk1.Name = "lb_hargaProduk1";
            this.lb_hargaProduk1.Size = new System.Drawing.Size(44, 16);
            this.lb_hargaProduk1.TabIndex = 12;
            this.lb_hargaProduk1.Text = "label1";
            // 
            // lb_hargaProduk2
            // 
            this.lb_hargaProduk2.AutoSize = true;
            this.lb_hargaProduk2.Location = new System.Drawing.Point(218, 296);
            this.lb_hargaProduk2.Name = "lb_hargaProduk2";
            this.lb_hargaProduk2.Size = new System.Drawing.Size(44, 16);
            this.lb_hargaProduk2.TabIndex = 13;
            this.lb_hargaProduk2.Text = "label1";
            // 
            // lb_hargaProduk3
            // 
            this.lb_hargaProduk3.AutoSize = true;
            this.lb_hargaProduk3.Location = new System.Drawing.Point(402, 296);
            this.lb_hargaProduk3.Name = "lb_hargaProduk3";
            this.lb_hargaProduk3.Size = new System.Drawing.Size(44, 16);
            this.lb_hargaProduk3.TabIndex = 14;
            this.lb_hargaProduk3.Text = "label1";
            // 
            // btn_add1
            // 
            this.btn_add1.Location = new System.Drawing.Point(15, 321);
            this.btn_add1.Name = "btn_add1";
            this.btn_add1.Size = new System.Drawing.Size(107, 29);
            this.btn_add1.TabIndex = 15;
            this.btn_add1.Text = "Add to Cart";
            this.btn_add1.UseVisualStyleBackColor = true;
            this.btn_add1.Click += new System.EventHandler(this.btn_add1_Click);
            // 
            // btn_add2
            // 
            this.btn_add2.Location = new System.Drawing.Point(221, 321);
            this.btn_add2.Name = "btn_add2";
            this.btn_add2.Size = new System.Drawing.Size(107, 29);
            this.btn_add2.TabIndex = 16;
            this.btn_add2.Text = "Add to Cart";
            this.btn_add2.UseVisualStyleBackColor = true;
            this.btn_add2.Click += new System.EventHandler(this.btn_add2_Click);
            // 
            // btn_add3
            // 
            this.btn_add3.Location = new System.Drawing.Point(405, 321);
            this.btn_add3.Name = "btn_add3";
            this.btn_add3.Size = new System.Drawing.Size(107, 29);
            this.btn_add3.TabIndex = 17;
            this.btn_add3.Text = "Add to Cart";
            this.btn_add3.UseVisualStyleBackColor = true;
            this.btn_add3.Click += new System.EventHandler(this.btn_add3_Click);
            // 
            // panel_pertama
            // 
            this.panel_pertama.Controls.Add(this.btn_add3);
            this.panel_pertama.Controls.Add(this.pBox_1);
            this.panel_pertama.Controls.Add(this.btn_add2);
            this.panel_pertama.Controls.Add(this.pBox_2);
            this.panel_pertama.Controls.Add(this.btn_add1);
            this.panel_pertama.Controls.Add(this.pBox_3);
            this.panel_pertama.Controls.Add(this.lb_hargaProduk3);
            this.panel_pertama.Controls.Add(this.lb_namaProduk1);
            this.panel_pertama.Controls.Add(this.lb_hargaProduk2);
            this.panel_pertama.Controls.Add(this.lb_namaProduk2);
            this.panel_pertama.Controls.Add(this.lb_hargaProduk1);
            this.panel_pertama.Controls.Add(this.lb_namaProduk3);
            this.panel_pertama.Location = new System.Drawing.Point(21, 51);
            this.panel_pertama.Name = "panel_pertama";
            this.panel_pertama.Size = new System.Drawing.Size(582, 370);
            this.panel_pertama.TabIndex = 18;
            // 
            // panel_kedua
            // 
            this.panel_kedua.Controls.Add(this.tb_itemPrice);
            this.panel_kedua.Controls.Add(this.tb_itemName);
            this.panel_kedua.Controls.Add(this.lb_itemPrice);
            this.panel_kedua.Controls.Add(this.lb_itemName);
            this.panel_kedua.Controls.Add(this.lb_uploadImage);
            this.panel_kedua.Controls.Add(this.btn_add4);
            this.panel_kedua.Controls.Add(this.btn_upload);
            this.panel_kedua.Controls.Add(this.pBox_4);
            this.panel_kedua.Location = new System.Drawing.Point(21, 51);
            this.panel_kedua.Name = "panel_kedua";
            this.panel_kedua.Size = new System.Drawing.Size(582, 370);
            this.panel_kedua.TabIndex = 19;
            // 
            // tb_itemPrice
            // 
            this.tb_itemPrice.Location = new System.Drawing.Point(298, 172);
            this.tb_itemPrice.Name = "tb_itemPrice";
            this.tb_itemPrice.Size = new System.Drawing.Size(155, 22);
            this.tb_itemPrice.TabIndex = 25;
            this.tb_itemPrice.TextChanged += new System.EventHandler(this.tb_itemPrice_TextChanged);
            this.tb_itemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_itemPrice_KeyPress);
            // 
            // tb_itemName
            // 
            this.tb_itemName.Location = new System.Drawing.Point(298, 113);
            this.tb_itemName.Name = "tb_itemName";
            this.tb_itemName.Size = new System.Drawing.Size(155, 22);
            this.tb_itemName.TabIndex = 24;
            this.tb_itemName.TextChanged += new System.EventHandler(this.tb_itemName_TextChanged);
            // 
            // lb_itemPrice
            // 
            this.lb_itemPrice.AutoSize = true;
            this.lb_itemPrice.Location = new System.Drawing.Point(295, 153);
            this.lb_itemPrice.Name = "lb_itemPrice";
            this.lb_itemPrice.Size = new System.Drawing.Size(69, 16);
            this.lb_itemPrice.TabIndex = 23;
            this.lb_itemPrice.Text = "Item Price:";
            // 
            // lb_itemName
            // 
            this.lb_itemName.AutoSize = true;
            this.lb_itemName.Location = new System.Drawing.Point(295, 94);
            this.lb_itemName.Name = "lb_itemName";
            this.lb_itemName.Size = new System.Drawing.Size(75, 16);
            this.lb_itemName.TabIndex = 22;
            this.lb_itemName.Text = "Item Name;";
            // 
            // lb_uploadImage
            // 
            this.lb_uploadImage.AutoSize = true;
            this.lb_uploadImage.Location = new System.Drawing.Point(107, 33);
            this.lb_uploadImage.Name = "lb_uploadImage";
            this.lb_uploadImage.Size = new System.Drawing.Size(93, 16);
            this.lb_uploadImage.TabIndex = 21;
            this.lb_uploadImage.Text = "Upload Image";
            // 
            // btn_add4
            // 
            this.btn_add4.Location = new System.Drawing.Point(298, 270);
            this.btn_add4.Name = "btn_add4";
            this.btn_add4.Size = new System.Drawing.Size(107, 33);
            this.btn_add4.TabIndex = 20;
            this.btn_add4.Text = "Add to Cart";
            this.btn_add4.UseVisualStyleBackColor = true;
            this.btn_add4.Click += new System.EventHandler(this.btn_add4_Click);
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(206, 24);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(107, 34);
            this.btn_upload.TabIndex = 19;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // pBox_4
            // 
            this.pBox_4.Location = new System.Drawing.Point(110, 70);
            this.pBox_4.Name = "pBox_4";
            this.pBox_4.Size = new System.Drawing.Size(152, 233);
            this.pBox_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_4.TabIndex = 18;
            this.pBox_4.TabStop = false;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1013, 34);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(94, 29);
            this.btn_delete.TabIndex = 20;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form_uniqme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 550);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.panel_kedua);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subTotal);
            this.Controls.Add(this.lb_total);
            this.Controls.Add(this.lb_subtotal);
            this.Controls.Add(this.dgv_shoppingList);
            this.Controls.Add(this.menuStrip_ClothShop);
            this.Controls.Add(this.panel_pertama);
            this.MainMenuStrip = this.menuStrip_ClothShop;
            this.Name = "Form_uniqme";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form_uniqme_Load);
            this.menuStrip_ClothShop.ResumeLayout(false);
            this.menuStrip_ClothShop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_shoppingList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_3)).EndInit();
            this.panel_pertama.ResumeLayout(false);
            this.panel_pertama.PerformLayout();
            this.panel_kedua.ResumeLayout(false);
            this.panel_kedua.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip_ClothShop;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_shoppingList;
        private System.Windows.Forms.Label lb_subtotal;
        private System.Windows.Forms.Label lb_total;
        private System.Windows.Forms.TextBox tb_subTotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.PictureBox pBox_1;
        private System.Windows.Forms.PictureBox pBox_2;
        private System.Windows.Forms.PictureBox pBox_3;
        private System.Windows.Forms.Label lb_namaProduk1;
        private System.Windows.Forms.Label lb_namaProduk2;
        private System.Windows.Forms.Label lb_namaProduk3;
        private System.Windows.Forms.Label lb_hargaProduk1;
        private System.Windows.Forms.Label lb_hargaProduk2;
        private System.Windows.Forms.Label lb_hargaProduk3;
        private System.Windows.Forms.Button btn_add1;
        private System.Windows.Forms.Button btn_add2;
        private System.Windows.Forms.Button btn_add3;
        private System.Windows.Forms.Panel panel_pertama;
        private System.Windows.Forms.Panel panel_kedua;
        private System.Windows.Forms.TextBox tb_itemPrice;
        private System.Windows.Forms.TextBox tb_itemName;
        private System.Windows.Forms.Label lb_itemPrice;
        private System.Windows.Forms.Label lb_itemName;
        private System.Windows.Forms.Label lb_uploadImage;
        private System.Windows.Forms.Button btn_add4;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.PictureBox pBox_4;
        private System.Windows.Forms.Button btn_delete;
    }
}

