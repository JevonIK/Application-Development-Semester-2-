﻿namespace AP_W02_Take_Home_words_guesser
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_word1 = new System.Windows.Forms.Label();
            this.lb_word2 = new System.Windows.Forms.Label();
            this.lb_word3 = new System.Windows.Forms.Label();
            this.lb_word4 = new System.Windows.Forms.Label();
            this.lb_word5 = new System.Windows.Forms.Label();
            this.tb_word1 = new System.Windows.Forms.TextBox();
            this.tb_word2 = new System.Windows.Forms.TextBox();
            this.tb_word3 = new System.Windows.Forms.TextBox();
            this.tb_word4 = new System.Windows.Forms.TextBox();
            this.tb_word5 = new System.Windows.Forms.TextBox();
            this.btn_play = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_word1
            // 
            this.lb_word1.AutoSize = true;
            this.lb_word1.Location = new System.Drawing.Point(50, 48);
            this.lb_word1.Name = "lb_word1";
            this.lb_word1.Size = new System.Drawing.Size(53, 16);
            this.lb_word1.TabIndex = 0;
            this.lb_word1.Text = "Word 1:";
            // 
            // lb_word2
            // 
            this.lb_word2.AutoSize = true;
            this.lb_word2.Location = new System.Drawing.Point(50, 78);
            this.lb_word2.Name = "lb_word2";
            this.lb_word2.Size = new System.Drawing.Size(53, 16);
            this.lb_word2.TabIndex = 1;
            this.lb_word2.Text = "Word 2:";
            // 
            // lb_word3
            // 
            this.lb_word3.AutoSize = true;
            this.lb_word3.Location = new System.Drawing.Point(50, 112);
            this.lb_word3.Name = "lb_word3";
            this.lb_word3.Size = new System.Drawing.Size(53, 16);
            this.lb_word3.TabIndex = 2;
            this.lb_word3.Text = "Word 3:";
            // 
            // lb_word4
            // 
            this.lb_word4.AutoSize = true;
            this.lb_word4.Location = new System.Drawing.Point(50, 143);
            this.lb_word4.Name = "lb_word4";
            this.lb_word4.Size = new System.Drawing.Size(53, 16);
            this.lb_word4.TabIndex = 3;
            this.lb_word4.Text = "Word 4:";
            // 
            // lb_word5
            // 
            this.lb_word5.AutoSize = true;
            this.lb_word5.Location = new System.Drawing.Point(50, 177);
            this.lb_word5.Name = "lb_word5";
            this.lb_word5.Size = new System.Drawing.Size(53, 16);
            this.lb_word5.TabIndex = 4;
            this.lb_word5.Text = "Word 5:";
            // 
            // tb_word1
            // 
            this.tb_word1.Location = new System.Drawing.Point(110, 45);
            this.tb_word1.Name = "tb_word1";
            this.tb_word1.Size = new System.Drawing.Size(100, 22);
            this.tb_word1.TabIndex = 5;
            // 
            // tb_word2
            // 
            this.tb_word2.Location = new System.Drawing.Point(109, 76);
            this.tb_word2.Name = "tb_word2";
            this.tb_word2.Size = new System.Drawing.Size(100, 22);
            this.tb_word2.TabIndex = 6;
            // 
            // tb_word3
            // 
            this.tb_word3.Location = new System.Drawing.Point(110, 106);
            this.tb_word3.Name = "tb_word3";
            this.tb_word3.Size = new System.Drawing.Size(100, 22);
            this.tb_word3.TabIndex = 7;
            // 
            // tb_word4
            // 
            this.tb_word4.Location = new System.Drawing.Point(109, 140);
            this.tb_word4.Name = "tb_word4";
            this.tb_word4.Size = new System.Drawing.Size(100, 22);
            this.tb_word4.TabIndex = 8;
            // 
            // tb_word5
            // 
            this.tb_word5.Location = new System.Drawing.Point(109, 171);
            this.tb_word5.Name = "tb_word5";
            this.tb_word5.Size = new System.Drawing.Size(100, 22);
            this.tb_word5.TabIndex = 9;
            // 
            // btn_play
            // 
            this.btn_play.Location = new System.Drawing.Point(120, 206);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(75, 23);
            this.btn_play.TabIndex = 10;
            this.btn_play.Text = "Play!";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.tb_word5);
            this.Controls.Add(this.tb_word4);
            this.Controls.Add(this.tb_word3);
            this.Controls.Add(this.tb_word2);
            this.Controls.Add(this.tb_word1);
            this.Controls.Add(this.lb_word5);
            this.Controls.Add(this.lb_word4);
            this.Controls.Add(this.lb_word3);
            this.Controls.Add(this.lb_word2);
            this.Controls.Add(this.lb_word1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_word1;
        private System.Windows.Forms.Label lb_word2;
        private System.Windows.Forms.Label lb_word3;
        private System.Windows.Forms.Label lb_word4;
        private System.Windows.Forms.Label lb_word5;
        private System.Windows.Forms.TextBox tb_word1;
        private System.Windows.Forms.TextBox tb_word2;
        private System.Windows.Forms.TextBox tb_word3;
        private System.Windows.Forms.TextBox tb_word4;
        private System.Windows.Forms.TextBox tb_word5;
        private System.Windows.Forms.Button btn_play;
    }
}

