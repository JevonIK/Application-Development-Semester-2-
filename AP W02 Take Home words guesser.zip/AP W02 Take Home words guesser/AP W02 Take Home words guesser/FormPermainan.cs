﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP_W02_Take_Home_words_guesser
{
    public partial class FormPermainan : Form
    {

        public List<string> wordStorage2;
        string answerKey;
        public FormPermainan()
        {
            InitializeComponent();
        }

        private void FormPermainan_Load(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int randomIndex = rnd.Next(wordStorage2.Count);
            answerKey = wordStorage2[randomIndex].ToUpper();
            lb_realanswer.Text = answerKey;
        }

        private void CheckAlphabet (char yes)
        {
            if (answerKey[0] == yes)
            {
                lb_w1.Text = yes.ToString();
            }

            if (answerKey[1] == yes)
            {
                lb_w2.Text = yes.ToString();
            }

            if (answerKey[2] == yes)
            {
                lb_w3.Text = yes.ToString();
            }

            if (answerKey[3] == yes)
            {
                lb_w4.Text = yes.ToString();
            }

            if (answerKey[4] == yes)
            {
                lb_w5.Text = yes.ToString();
            }

            //Pengecekan jika menang
            string userAnswer = lb_w1.Text + lb_w2.Text + lb_w3.Text + lb_w4.Text + lb_w5.Text;
            if (userAnswer == answerKey)
            {
                MessageBox.Show("You Win");
            }
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            CheckAlphabet('Q');
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            CheckAlphabet('W');
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            CheckAlphabet('E');
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            CheckAlphabet('R');
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            CheckAlphabet('T');
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            CheckAlphabet('Y');
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            CheckAlphabet('U');
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            CheckAlphabet('I');
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            CheckAlphabet('O');
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            CheckAlphabet('P');
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            CheckAlphabet('A');
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            CheckAlphabet('S');
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            CheckAlphabet('D');
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            CheckAlphabet('F');
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            CheckAlphabet('G');
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            CheckAlphabet('H');
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            CheckAlphabet('J');
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            CheckAlphabet('K');
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            CheckAlphabet('L');
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            CheckAlphabet('Z');
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            CheckAlphabet('X');
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            CheckAlphabet('C');
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            CheckAlphabet('V');
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            CheckAlphabet('B');
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            CheckAlphabet('N');
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            CheckAlphabet('M');
        }
    }
}
