﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP_W02_Take_Home_words_guesser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<string> wordStorage = new List<string>();

        private void btn_play_Click(object sender, EventArgs e)
        {
            wordStorage.Add(tb_word1.Text.ToUpper());
            wordStorage.Add(tb_word2.Text.ToUpper());
            wordStorage.Add(tb_word3.Text.ToUpper());
            wordStorage.Add(tb_word4.Text.ToUpper());
            wordStorage.Add(tb_word5.Text.ToUpper());

            if (CheckErrors() == true)
            {
                wordStorage.Clear();
            }
            else
            {
                MessageBox.Show("Let's play");
                FormPermainan form2 = new FormPermainan();
                form2.wordStorage2 = wordStorage;
                form2.ShowDialog();
            }
        }

        private bool CheckErrors()
        {
            bool isError = false;

            // Cek 5 box harus terisi
            foreach (string word in wordStorage)
            {
                if (word == "")
                {
                    MessageBox.Show("Kelima kata harus terisi, tidak boleh kosong");
                    isError = true;
                    break;
                }
            }

            // cek setiap kata harus 5 huruf
            if (isError == false)
            {
                foreach (string word in wordStorage)
                {
                    if (word.Length != 5)
                    {
                        MessageBox.Show("Setiap kata harus mengandung 5 huruf");
                        isError = true;
                        break;
                    }
                }
            }

            // cek kata tidak boleh mengandung angka
            if (isError == false)
            {
                foreach (string word in wordStorage)
                {
                    foreach (char alphabet in word)
                    {
                        if (char.IsDigit(alphabet))
                        {
                            MessageBox.Show("Kata tidak boleh mengandung angka");
                            isError = true;
                            break;
                        }
                    }
                }
            }

            // cek apakah ada kata terduplikat
            if (isError == false)
            {
                int counterSama = 0;
                for (int i = 0; i < wordStorage.Count; i++)
                {
                    for (int j = 0; j < wordStorage.Count; j++)
                    {
                        if (wordStorage[i] == wordStorage[j])
                        {
                            counterSama++;
                        }
                    }
                }
                if (counterSama != 5)
                {
                    MessageBox.Show("Kata tidak boleh sama");
                    isError = true;
                }
            }

            return isError;
        }
    }
}
