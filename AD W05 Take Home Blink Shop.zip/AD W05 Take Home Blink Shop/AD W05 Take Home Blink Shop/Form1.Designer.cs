﻿namespace AD_W05_Take_Home_Blink_Shop
{
    partial class mainForm_BlinkShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_judulProduct = new System.Windows.Forms.Label();
            this.lb_judulCategory = new System.Windows.Forms.Label();
            this.dgv_product = new System.Windows.Forms.DataGridView();
            this.dgv_category = new System.Windows.Forms.DataGridView();
            this.btn_searchFilter = new System.Windows.Forms.Button();
            this.btn_searchAll = new System.Windows.Forms.Button();
            this.cb_chooseFilter = new System.Windows.Forms.ComboBox();
            this.lb_namaCategory = new System.Windows.Forms.Label();
            this.tb_namaCategory = new System.Windows.Forms.TextBox();
            this.btn_addCategory = new System.Windows.Forms.Button();
            this.btn_removeCategory = new System.Windows.Forms.Button();
            this.lb_judulDetails = new System.Windows.Forms.Label();
            this.lb_namaProduct = new System.Windows.Forms.Label();
            this.lb_categoryProduct = new System.Windows.Forms.Label();
            this.lb_hargaProduct = new System.Windows.Forms.Label();
            this.lb_stockProduct = new System.Windows.Forms.Label();
            this.tb_namaProduct = new System.Windows.Forms.TextBox();
            this.cb_categoryProduct = new System.Windows.Forms.ComboBox();
            this.tb_hargaProduct = new System.Windows.Forms.TextBox();
            this.tb_stockProduct = new System.Windows.Forms.TextBox();
            this.btn_addProduct = new System.Windows.Forms.Button();
            this.btn_editProduct = new System.Windows.Forms.Button();
            this.btn_removeProduct = new System.Windows.Forms.Button();
            this.picture_hiasan = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture_hiasan)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_judulProduct
            // 
            this.lb_judulProduct.AutoSize = true;
            this.lb_judulProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_judulProduct.Location = new System.Drawing.Point(36, 42);
            this.lb_judulProduct.Name = "lb_judulProduct";
            this.lb_judulProduct.Size = new System.Drawing.Size(103, 29);
            this.lb_judulProduct.TabIndex = 0;
            this.lb_judulProduct.Text = "Product";
            // 
            // lb_judulCategory
            // 
            this.lb_judulCategory.AutoSize = true;
            this.lb_judulCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_judulCategory.Location = new System.Drawing.Point(528, 42);
            this.lb_judulCategory.Name = "lb_judulCategory";
            this.lb_judulCategory.Size = new System.Drawing.Size(118, 29);
            this.lb_judulCategory.TabIndex = 1;
            this.lb_judulCategory.Text = "Category";
            // 
            // dgv_product
            // 
            this.dgv_product.AllowUserToAddRows = false;
            this.dgv_product.AllowUserToDeleteRows = false;
            this.dgv_product.AllowUserToResizeColumns = false;
            this.dgv_product.AllowUserToResizeRows = false;
            this.dgv_product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_product.Location = new System.Drawing.Point(41, 83);
            this.dgv_product.Name = "dgv_product";
            this.dgv_product.RowHeadersVisible = false;
            this.dgv_product.RowHeadersWidth = 51;
            this.dgv_product.RowTemplate.Height = 24;
            this.dgv_product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_product.Size = new System.Drawing.Size(450, 279);
            this.dgv_product.TabIndex = 2;
            this.dgv_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_product_CellClick);
            // 
            // dgv_category
            // 
            this.dgv_category.AllowUserToAddRows = false;
            this.dgv_category.AllowUserToDeleteRows = false;
            this.dgv_category.AllowUserToResizeColumns = false;
            this.dgv_category.AllowUserToResizeRows = false;
            this.dgv_category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_category.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_category.Location = new System.Drawing.Point(533, 83);
            this.dgv_category.Name = "dgv_category";
            this.dgv_category.RowHeadersVisible = false;
            this.dgv_category.RowHeadersWidth = 51;
            this.dgv_category.RowTemplate.Height = 24;
            this.dgv_category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_category.Size = new System.Drawing.Size(263, 175);
            this.dgv_category.TabIndex = 3;
            this.dgv_category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_category_CellClick);
            // 
            // btn_searchFilter
            // 
            this.btn_searchFilter.Location = new System.Drawing.Point(293, 49);
            this.btn_searchFilter.Name = "btn_searchFilter";
            this.btn_searchFilter.Size = new System.Drawing.Size(55, 23);
            this.btn_searchFilter.TabIndex = 4;
            this.btn_searchFilter.Text = "Filter:";
            this.btn_searchFilter.UseVisualStyleBackColor = true;
            this.btn_searchFilter.Click += new System.EventHandler(this.btn_searchFilter_Click);
            // 
            // btn_searchAll
            // 
            this.btn_searchAll.Location = new System.Drawing.Point(240, 49);
            this.btn_searchAll.Name = "btn_searchAll";
            this.btn_searchAll.Size = new System.Drawing.Size(47, 23);
            this.btn_searchAll.TabIndex = 5;
            this.btn_searchAll.Text = "All";
            this.btn_searchAll.UseVisualStyleBackColor = true;
            this.btn_searchAll.Click += new System.EventHandler(this.btn_searchAll_Click);
            // 
            // cb_chooseFilter
            // 
            this.cb_chooseFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_chooseFilter.FormattingEnabled = true;
            this.cb_chooseFilter.Location = new System.Drawing.Point(354, 49);
            this.cb_chooseFilter.Name = "cb_chooseFilter";
            this.cb_chooseFilter.Size = new System.Drawing.Size(137, 24);
            this.cb_chooseFilter.TabIndex = 6;
            this.cb_chooseFilter.SelectedIndexChanged += new System.EventHandler(this.cb_chooseFilter_SelectedIndexChanged);
            // 
            // lb_namaCategory
            // 
            this.lb_namaCategory.AutoSize = true;
            this.lb_namaCategory.Location = new System.Drawing.Point(533, 281);
            this.lb_namaCategory.Name = "lb_namaCategory";
            this.lb_namaCategory.Size = new System.Drawing.Size(47, 16);
            this.lb_namaCategory.TabIndex = 7;
            this.lb_namaCategory.Text = "Nama:";
            // 
            // tb_namaCategory
            // 
            this.tb_namaCategory.Location = new System.Drawing.Point(591, 278);
            this.tb_namaCategory.Name = "tb_namaCategory";
            this.tb_namaCategory.Size = new System.Drawing.Size(205, 22);
            this.tb_namaCategory.TabIndex = 8;
            // 
            // btn_addCategory
            // 
            this.btn_addCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_addCategory.Location = new System.Drawing.Point(604, 306);
            this.btn_addCategory.Name = "btn_addCategory";
            this.btn_addCategory.Size = new System.Drawing.Size(93, 56);
            this.btn_addCategory.TabIndex = 9;
            this.btn_addCategory.Text = "Add Category";
            this.btn_addCategory.UseVisualStyleBackColor = false;
            this.btn_addCategory.Click += new System.EventHandler(this.btn_addCategory_Click);
            // 
            // btn_removeCategory
            // 
            this.btn_removeCategory.BackColor = System.Drawing.Color.Red;
            this.btn_removeCategory.Location = new System.Drawing.Point(703, 306);
            this.btn_removeCategory.Name = "btn_removeCategory";
            this.btn_removeCategory.Size = new System.Drawing.Size(93, 56);
            this.btn_removeCategory.TabIndex = 10;
            this.btn_removeCategory.Text = "Remove Category";
            this.btn_removeCategory.UseVisualStyleBackColor = false;
            this.btn_removeCategory.Click += new System.EventHandler(this.btn_removeCategory_Click);
            // 
            // lb_judulDetails
            // 
            this.lb_judulDetails.AutoSize = true;
            this.lb_judulDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_judulDetails.Location = new System.Drawing.Point(36, 391);
            this.lb_judulDetails.Name = "lb_judulDetails";
            this.lb_judulDetails.Size = new System.Drawing.Size(94, 29);
            this.lb_judulDetails.TabIndex = 11;
            this.lb_judulDetails.Text = "Details";
            // 
            // lb_namaProduct
            // 
            this.lb_namaProduct.AutoSize = true;
            this.lb_namaProduct.Location = new System.Drawing.Point(55, 432);
            this.lb_namaProduct.Name = "lb_namaProduct";
            this.lb_namaProduct.Size = new System.Drawing.Size(47, 16);
            this.lb_namaProduct.TabIndex = 12;
            this.lb_namaProduct.Text = "Nama:";
            // 
            // lb_categoryProduct
            // 
            this.lb_categoryProduct.AutoSize = true;
            this.lb_categoryProduct.Location = new System.Drawing.Point(38, 459);
            this.lb_categoryProduct.Name = "lb_categoryProduct";
            this.lb_categoryProduct.Size = new System.Drawing.Size(65, 16);
            this.lb_categoryProduct.TabIndex = 13;
            this.lb_categoryProduct.Text = "Category:";
            // 
            // lb_hargaProduct
            // 
            this.lb_hargaProduct.AutoSize = true;
            this.lb_hargaProduct.Location = new System.Drawing.Point(54, 491);
            this.lb_hargaProduct.Name = "lb_hargaProduct";
            this.lb_hargaProduct.Size = new System.Drawing.Size(48, 16);
            this.lb_hargaProduct.TabIndex = 14;
            this.lb_hargaProduct.Text = "Harga:";
            // 
            // lb_stockProduct
            // 
            this.lb_stockProduct.AutoSize = true;
            this.lb_stockProduct.Location = new System.Drawing.Point(58, 522);
            this.lb_stockProduct.Name = "lb_stockProduct";
            this.lb_stockProduct.Size = new System.Drawing.Size(44, 16);
            this.lb_stockProduct.TabIndex = 15;
            this.lb_stockProduct.Text = "Stock:";
            // 
            // tb_namaProduct
            // 
            this.tb_namaProduct.Location = new System.Drawing.Point(123, 426);
            this.tb_namaProduct.Name = "tb_namaProduct";
            this.tb_namaProduct.Size = new System.Drawing.Size(368, 22);
            this.tb_namaProduct.TabIndex = 16;
            this.tb_namaProduct.TextChanged += new System.EventHandler(this.tb_namaProduct_TextChanged);
            // 
            // cb_categoryProduct
            // 
            this.cb_categoryProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_categoryProduct.FormattingEnabled = true;
            this.cb_categoryProduct.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cb_categoryProduct.Location = new System.Drawing.Point(123, 456);
            this.cb_categoryProduct.Name = "cb_categoryProduct";
            this.cb_categoryProduct.Size = new System.Drawing.Size(107, 24);
            this.cb_categoryProduct.TabIndex = 17;
            this.cb_categoryProduct.SelectedIndexChanged += new System.EventHandler(this.cb_categoryProduct_SelectedIndexChanged);
            // 
            // tb_hargaProduct
            // 
            this.tb_hargaProduct.Location = new System.Drawing.Point(123, 488);
            this.tb_hargaProduct.Name = "tb_hargaProduct";
            this.tb_hargaProduct.Size = new System.Drawing.Size(107, 22);
            this.tb_hargaProduct.TabIndex = 18;
            this.tb_hargaProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_hargaProduct_KeyPress);
            // 
            // tb_stockProduct
            // 
            this.tb_stockProduct.Location = new System.Drawing.Point(123, 519);
            this.tb_stockProduct.Name = "tb_stockProduct";
            this.tb_stockProduct.Size = new System.Drawing.Size(107, 22);
            this.tb_stockProduct.TabIndex = 19;
            this.tb_stockProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stockProduct_KeyPress);
            // 
            // btn_addProduct
            // 
            this.btn_addProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_addProduct.Location = new System.Drawing.Point(249, 464);
            this.btn_addProduct.Name = "btn_addProduct";
            this.btn_addProduct.Size = new System.Drawing.Size(77, 70);
            this.btn_addProduct.TabIndex = 20;
            this.btn_addProduct.Text = "Add Product";
            this.btn_addProduct.UseVisualStyleBackColor = false;
            this.btn_addProduct.Click += new System.EventHandler(this.btn_addProduct_Click);
            // 
            // btn_editProduct
            // 
            this.btn_editProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_editProduct.Location = new System.Drawing.Point(332, 464);
            this.btn_editProduct.Name = "btn_editProduct";
            this.btn_editProduct.Size = new System.Drawing.Size(77, 70);
            this.btn_editProduct.TabIndex = 21;
            this.btn_editProduct.Text = "Edit Product";
            this.btn_editProduct.UseVisualStyleBackColor = false;
            this.btn_editProduct.Click += new System.EventHandler(this.btn_editProduct_Click);
            // 
            // btn_removeProduct
            // 
            this.btn_removeProduct.BackColor = System.Drawing.Color.Red;
            this.btn_removeProduct.Location = new System.Drawing.Point(415, 464);
            this.btn_removeProduct.Name = "btn_removeProduct";
            this.btn_removeProduct.Size = new System.Drawing.Size(76, 70);
            this.btn_removeProduct.TabIndex = 22;
            this.btn_removeProduct.Text = "Remove Product";
            this.btn_removeProduct.UseVisualStyleBackColor = false;
            this.btn_removeProduct.Click += new System.EventHandler(this.btn_removeProduct_Click);
            // 
            // picture_hiasan
            // 
            this.picture_hiasan.Image = global::AD_W05_Take_Home_Blink_Shop.Properties.Resources.klipartz1;
            this.picture_hiasan.Location = new System.Drawing.Point(553, 381);
            this.picture_hiasan.Name = "picture_hiasan";
            this.picture_hiasan.Size = new System.Drawing.Size(298, 184);
            this.picture_hiasan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture_hiasan.TabIndex = 23;
            this.picture_hiasan.TabStop = false;
            // 
            // mainForm_BlinkShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(849, 564);
            this.Controls.Add(this.picture_hiasan);
            this.Controls.Add(this.btn_removeProduct);
            this.Controls.Add(this.btn_editProduct);
            this.Controls.Add(this.btn_addProduct);
            this.Controls.Add(this.tb_stockProduct);
            this.Controls.Add(this.tb_hargaProduct);
            this.Controls.Add(this.cb_categoryProduct);
            this.Controls.Add(this.tb_namaProduct);
            this.Controls.Add(this.lb_stockProduct);
            this.Controls.Add(this.lb_hargaProduct);
            this.Controls.Add(this.lb_categoryProduct);
            this.Controls.Add(this.lb_namaProduct);
            this.Controls.Add(this.lb_judulDetails);
            this.Controls.Add(this.btn_removeCategory);
            this.Controls.Add(this.btn_addCategory);
            this.Controls.Add(this.tb_namaCategory);
            this.Controls.Add(this.lb_namaCategory);
            this.Controls.Add(this.cb_chooseFilter);
            this.Controls.Add(this.btn_searchAll);
            this.Controls.Add(this.btn_searchFilter);
            this.Controls.Add(this.dgv_category);
            this.Controls.Add(this.dgv_product);
            this.Controls.Add(this.lb_judulCategory);
            this.Controls.Add(this.lb_judulProduct);
            this.Name = "mainForm_BlinkShop";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.mainForm_BlinkShop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture_hiasan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_judulProduct;
        private System.Windows.Forms.Label lb_judulCategory;
        private System.Windows.Forms.DataGridView dgv_product;
        private System.Windows.Forms.DataGridView dgv_category;
        private System.Windows.Forms.Button btn_searchFilter;
        private System.Windows.Forms.Button btn_searchAll;
        private System.Windows.Forms.ComboBox cb_chooseFilter;
        private System.Windows.Forms.Label lb_namaCategory;
        private System.Windows.Forms.TextBox tb_namaCategory;
        private System.Windows.Forms.Button btn_addCategory;
        private System.Windows.Forms.Button btn_removeCategory;
        private System.Windows.Forms.Label lb_judulDetails;
        private System.Windows.Forms.Label lb_namaProduct;
        private System.Windows.Forms.Label lb_categoryProduct;
        private System.Windows.Forms.Label lb_hargaProduct;
        private System.Windows.Forms.Label lb_stockProduct;
        private System.Windows.Forms.TextBox tb_namaProduct;
        private System.Windows.Forms.ComboBox cb_categoryProduct;
        private System.Windows.Forms.TextBox tb_hargaProduct;
        private System.Windows.Forms.TextBox tb_stockProduct;
        private System.Windows.Forms.Button btn_addProduct;
        private System.Windows.Forms.Button btn_editProduct;
        private System.Windows.Forms.Button btn_removeProduct;
        private System.Windows.Forms.PictureBox picture_hiasan;
    }
}

