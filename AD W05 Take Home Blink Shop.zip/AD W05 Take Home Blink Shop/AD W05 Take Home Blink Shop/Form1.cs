﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AD_W05_Take_Home_Blink_Shop
{
    public partial class mainForm_BlinkShop : Form
    {
        DataTable dtProdukSimpan; // untuk menyimpan data produk
        DataTable dtProdukTampil; // untuk menampilkan data produk  hasil filter
        DataTable dtCategory; // untuk menyimpan data category 

        int selectedIndex = 0; // untuk dgv product
        int selectedCategory = 0; // untuk dgv category

        public mainForm_BlinkShop()
        {
            InitializeComponent();
        }

        private void mainForm_BlinkShop_Load(object sender, EventArgs e)
        {
            dtProdukSimpan = new DataTable();
            dtProdukTampil = new DataTable();
            dtCategory = new DataTable();


            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");

            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", 100000, 10, "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", 70000, 20, "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", 75000, 16, "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", 82000, 26, "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", 90000, 5, "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", 60000, 11, "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", 1000000, 1, "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", 50000, 8, "C2");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");


            cb_chooseFilter.Enabled = false;

            cb_categoryProduct.DataSource = dtCategory;
            cb_categoryProduct.DisplayMember = "Nama Category";

            cb_chooseFilter.DataSource = dtCategory;
            cb_chooseFilter.DisplayMember = "Nama Category";

            dtProdukTampil = dtProdukSimpan; //show yg awal sudah disetor

            dgv_product.DataSource = dtProdukTampil;
            dgv_category.DataSource = dtCategory;

            // untuk tambahan detail

            dgv_product.Columns[1].Width = 100;

            cb_categoryProduct.SelectedIndex = -1;
            cb_chooseFilter.SelectedIndex = -1;

            dgv_product.ClearSelection();
            dgv_category.ClearSelection();

            //btn_searchAll.PerformClick();
        }

        private void btn_searchAll_Click(object sender, EventArgs e)
        {
            cb_chooseFilter.Enabled = false;
            dtProdukTampil = dtProdukSimpan;
            dgv_product.DataSource = dtProdukTampil;

            // small detail
            cb_chooseFilter.SelectedIndex = -1; 
            dgv_product.ClearSelection();
        }

        private void btn_searchFilter_Click(object sender, EventArgs e)
        {
            cb_chooseFilter.Enabled = true;
            cb_chooseFilter.DataSource = dtCategory;
            cb_chooseFilter.DisplayMember = "Nama Product";

            // small detail
            cb_chooseFilter.SelectedIndex = -1;
            dgv_product.ClearSelection();
        }

        private void cb_chooseFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_chooseFilter.Enabled == false)
            {
                
            }
            else if(cb_chooseFilter.Enabled == true)
            {
                if (cb_chooseFilter.SelectedIndex != -1)
                {
                    dtProdukTampil = new DataTable();

                    int indexChooseFilter = cb_chooseFilter.SelectedIndex;
                    dtProdukTampil.Columns.Add("ID Product");
                    dtProdukTampil.Columns.Add("Nama Product");
                    dtProdukTampil.Columns.Add("Harga");
                    dtProdukTampil.Columns.Add("Stock");
                    dtProdukTampil.Columns.Add("ID Category");

                    foreach (DataRow dr in dtProdukSimpan.Rows)
                    {
                        if (dr["ID Category"] == dtCategory.Rows[indexChooseFilter]["ID Category"].ToString())
                        {
                            dtProdukTampil.Rows.Add(dr["ID Product"], dr["Nama Product"], dr["Harga"], dr["Stock"], dr["ID Category"]);
                        }
                    }
                    dgv_product.DataSource = dtProdukTampil;
                }
                else
                {
                    dgv_product.DataSource = dtProdukSimpan;
                }
            }
            

        }

        private void btn_addProduct_Click(object sender, EventArgs e)
        {
            if (tb_namaProduct.Text == "" || tb_hargaProduct.Text == "" || tb_stockProduct.Text == "")
            {
                MessageBox.Show("Semua input harus diisi!", "Error");
            }
            else if (cb_categoryProduct.SelectedIndex == -1)
            {
                MessageBox.Show("Silahkan pilih category terlebih dahulu", "Error");
            }
            else
            {
                string realIDProduct = NumberFormatting(tb_namaProduct.Text.ToUpper()[0]);
                int index = cb_categoryProduct.SelectedIndex;
                dtProdukSimpan.Rows.Add(realIDProduct, tb_namaProduct.Text, tb_hargaProduct.Text, tb_stockProduct.Text, dtCategory.Rows[index]["ID Category"]);
                dtProdukTampil = dtProdukSimpan;
                dgv_product.DataSource = dtProdukTampil;

                tb_namaProduct.Text = "";
                cb_categoryProduct.SelectedIndex = -1;
                tb_hargaProduct.Text = "";
                tb_stockProduct.Text = "";
                
            }
        }

        private string NumberFormatting(char initial) 
        {
            int highestIdNumber = 0;

            foreach (DataRow dr in dtProdukSimpan.Rows)
            {
                string id = dr["ID Product"].ToString();
                if (id.Length > 1 && id[0] == initial && int.TryParse(id.Substring(1), out int idNumber))
                {
                    if (idNumber > highestIdNumber)
                    {
                        highestIdNumber = idNumber;
                    }
                }
            }

            return initial.ToString() + (highestIdNumber + 1).ToString("000");

        }

        private void tb_hargaProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_stockProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_editProduct_Click(object sender, EventArgs e)
        {
            if (dgv_product.SelectedCells.Count == 0)
            {
                MessageBox.Show("Pilih dahulu produk yang ingin diedit", "Error");
            }
            else if (tb_namaProduct.Text == "" || tb_hargaProduct.Text == "" || tb_stockProduct.Text == "")
            {
                MessageBox.Show("Semua input harus diisi!", "Error");
            }
            else if (cb_categoryProduct.SelectedIndex == -1)
            {
                MessageBox.Show("Silahkan pilih category dulu", "Error");
            }
            else
            {
                if (Convert.ToInt32(tb_stockProduct.Text) == 0)
                {
                    dtProdukSimpan.Rows.RemoveAt(selectedIndex);
                }
                else
                {
                    dtProdukSimpan.Rows[selectedIndex]["Nama Product"] = tb_namaProduct.Text;
                    dtProdukSimpan.Rows[selectedIndex]["Harga"] = tb_hargaProduct.Text;
                    dtProdukSimpan.Rows[selectedIndex]["Stock"] = tb_stockProduct.Text;
                    dtProdukSimpan.Rows[selectedIndex]["ID Category"] = dtCategory.Rows[cb_categoryProduct.SelectedIndex]["ID Category"];
                }
                dtProdukTampil = dtProdukSimpan;
                dgv_product.DataSource = dtProdukTampil;              
            }

            tb_namaProduct.Text = "";
            cb_categoryProduct.SelectedIndex = -1;
            tb_hargaProduct.Text = "";
            tb_stockProduct.Text = "";

            dgv_product.ClearSelection();
        }

        private void btn_removeProduct_Click(object sender, EventArgs e)
        {
            if (dgv_product.SelectedCells.Count == 0)
            {
                // nothing happens
            }

            else
            {
                DataGridViewRow selectedRow = dgv_product.SelectedRows[0];
                string selectedProductId = selectedRow.Cells["ID Product"].Value.ToString();

                int selectedIndexInMain = -1;
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i]["ID Product"].ToString() == selectedProductId)
                    {
                        selectedIndexInMain = i;
                        break;
                    }
                }

                if (selectedIndexInMain != -1)
                {
                    dtProdukSimpan.Rows.RemoveAt(selectedIndexInMain);

                    if (cb_chooseFilter.Enabled)
                    {
                        cb_chooseFilter_SelectedIndexChanged(sender, e);
                    }
                    else
                    {
                        dgv_product.DataSource = dtProdukSimpan;
                    }


                    tb_namaProduct.Text = "";
                    cb_categoryProduct.SelectedIndex = -1;
                    tb_hargaProduct.Text = "";
                    tb_stockProduct.Text = "";
                }

            }


            dgv_product.ClearSelection();
        }

        private void dgv_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = dgv_product.Rows[e.RowIndex];
                tb_namaProduct.Text = selectedRow.Cells["Nama Product"].Value.ToString();
                tb_hargaProduct.Text = selectedRow.Cells["Harga"].Value.ToString();
                tb_stockProduct.Text = selectedRow.Cells["Stock"].Value.ToString();

                string catProductID = selectedRow.Cells["ID Category"].Value.ToString();


                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i]["ID Category"].ToString() == catProductID)
                    {
                        cb_categoryProduct.SelectedIndex = i;
                    }
                }

                selectedIndex = e.RowIndex;
            }

            dgv_category.ClearSelection();

            if (cb_chooseFilter.Enabled == false)
            {
                cb_chooseFilter.SelectedIndex = -1;
            }
        }

        private void btn_addCategory_Click(object sender, EventArgs e)
        {
            if (tb_namaCategory.Text == "")
            {
                MessageBox.Show("Masukkan nama category terlebih dahulu", "Error");
            }
            else
            {
                bool categoryExists = false;
                foreach (DataRow row in dtCategory.Rows)
                {
                    if (row["Nama Category"].ToString() == tb_namaCategory.Text)
                    {
                        categoryExists = true;
                        break;
                    }
                }

                if (categoryExists)
                {
                    MessageBox.Show("Category sudah ada", "Error");
                }
                else // berhasil
                {
                    string idCategoryNew = NumberFormattingCategory();
                    dtCategory.Rows.Add(idCategoryNew, tb_namaCategory.Text);
                    dgv_category.DataSource = dtCategory;
                    cb_categoryProduct.DataSource = dtCategory;
                    cb_categoryProduct.DisplayMember = "Nama Category";

                    dgv_category.ClearSelection();
                    tb_namaCategory.Text = "";
                }

                
            }

            // detail kecil
            cb_categoryProduct.SelectedIndex = -1;
            cb_chooseFilter.SelectedIndex = -1;

        }

        private string NumberFormattingCategory()
        {
            string latestId = dtCategory.Rows[dtCategory.Rows.Count - 1]["ID Category"].ToString();
            int highestIdNumber = Convert.ToInt32(latestId.Replace("C", ""));
            return "C" + (highestIdNumber + 1).ToString();
        }

        private void btn_removeCategory_Click(object sender, EventArgs e)
        {


            if (dgv_category.SelectedCells.Count == 0)
            {
                // nothing happens
            }
            else
            {
                string removedCategory = dtCategory.Rows[selectedCategory]["ID Category"].ToString();
                dtCategory.Rows.RemoveAt(selectedCategory);
                dgv_category.DataSource = dtCategory;
                cb_categoryProduct.DataSource = dtCategory;
                cb_categoryProduct.DisplayMember = "Nama Category";

                List<int> removedIndexList = new List<int>();
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i]["ID Category"].ToString() == removedCategory)
                    {
                        removedIndexList.Add(i);
                    }
                }

                foreach (int j in removedIndexList)
                {
                    ItemRemover(removedCategory);
                }

                dtProdukTampil = dtProdukSimpan;
                dgv_product.DataSource = dtProdukTampil;

                dgv_category.ClearSelection();
                tb_namaCategory.Text = "";
            }

            dgv_category.ClearSelection();

            // detail kecil
            cb_categoryProduct.SelectedIndex = -1;
            cb_chooseFilter.SelectedIndex = -1;
        }

        private void ItemRemover(string removedCategory)
        {
            List<int> removedIndex = new List<int>();
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i]["ID Category"].ToString() == removedCategory)
                {
                    removedIndex.Add(i);
                    break;
                }
            }
            dtProdukSimpan.Rows.RemoveAt(removedIndex[0]);
        }

        private void dgv_category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRowCategory = dgv_category.Rows[e.RowIndex];
                tb_namaCategory.Text = selectedRowCategory.Cells["Nama Category"].Value.ToString();

                selectedCategory = e.RowIndex;

            }

            // detail kecil
            cb_categoryProduct.SelectedIndex = -1;
            cb_chooseFilter.SelectedIndex = -1;
        }

        private void tb_namaProduct_TextChanged(object sender, EventArgs e)
        {

        }

        private void cb_categoryProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
