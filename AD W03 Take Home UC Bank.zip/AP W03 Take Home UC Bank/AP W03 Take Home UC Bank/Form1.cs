﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP_W03_Take_Home_UC_Bank
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataTable dtBankUC = new DataTable();
        int accountNumber = 0;
        int choosenAccount;

        private void Form1_Load(object sender, EventArgs e)
        {
            dtBankUC.Columns.Add("Username");
            dtBankUC.Columns.Add("Password");
            dtBankUC.Columns.Add("Balance");
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            panel_login.Visible = false;
            panel_register.Visible = true;
        }

        private void btn_RegisterReal_Click(object sender, EventArgs e)
        {
            int counterSama = 0;
            for (int i = 0; i < dtBankUC.Rows.Count; i++)
            {
                if (dtBankUC.Rows[i][0].ToString() == tb_usernameReg.Text)
                {
                    counterSama++;
                }
            }
            if (tb_usernameReg.Text == "" && tb_passwordReg.Text == "")
            {
                MessageBox.Show("Must Fill Username and Password!");
            }
            else if (counterSama > 0)
            {
                MessageBox.Show("Username has been used");
            }
            else if (counterSama == 0)
            {
                MessageBox.Show("Register Successful");
                dtBankUC.Rows.Add(tb_usernameReg.Text, tb_passwordReg.Text, "0");
                accountNumber++;
                panel_register.Visible = false;
                panel_login.Visible = true;
                
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            bool akunBenar = false;
            if (tb_usernameLog.Text == "" && tb_passwordLog.Text == "")
            {
                MessageBox.Show("Username and Password not Found!");
            }

            else if (accountNumber == 0)
            {
                MessageBox.Show("Username and Password not Found!");
            }

            else if (accountNumber > 0) 
            {
                for (int i = 0; i < dtBankUC.Rows.Count; i++)
                {
                    if (dtBankUC.Rows[i][0].ToString() == tb_usernameLog.Text)
                    {
                        choosenAccount = i;
                        akunBenar = true;
                    }
                }

                
                if (akunBenar == true && dtBankUC.Rows[choosenAccount][1].ToString() == tb_passwordLog.Text)
                {
                    MessageBox.Show("Login Succesful");
                    long uang = Convert.ToInt64(dtBankUC.Rows[choosenAccount][2]);
                    lb_balanceCount.Text = "Rp" + uang.ToString("N");
                    lb_balanceWith.Text = "Rp " + uang.ToString("N");
                    panel_login.Visible = false;
                    panel_mainBalance.Visible = true;
                    btn_logOut.Visible = true;
                }

                else
                {
                    MessageBox.Show("Username and Password not Found");
                }
            }

        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            panel_mainBalance.Visible = false;
            panel_deposit.Visible = true;
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            panel_mainBalance.Visible = false;
            long uang = Convert.ToInt64(dtBankUC.Rows[choosenAccount][2]);
            lb_balanceWith.Text = "Rp " + uang.ToString("N");
            lb_balanceCount.Text = "Rp " + uang.ToString("N");
            panel_withdraw.Visible = true;
        }

        private void ProsesDeposit(long x)
        {
            long uang = Convert.ToInt64(dtBankUC.Rows[choosenAccount][2]);
            if (x > 0)
            {
                uang = x + uang;
                dtBankUC.Rows[choosenAccount][2] = uang;
                MessageBox.Show("Succesfully Add Deposit");
                tb_inputDeposit.Text = "";
                panel_deposit.Visible = false;
                panel_mainBalance.Visible = true;
            }
            else if (x <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
        }

        private void btn_inputDeposit_Click(object sender, EventArgs e)
        {
            ProsesDeposit(Convert.ToInt64(tb_inputDeposit.Text));
            long uang = Convert.ToInt64(dtBankUC.Rows[choosenAccount][2]);
            lb_balanceCount.Text = "Rp " + uang.ToString("N");
            lb_balanceWith.Text = "Rp " + uang.ToString("N");
        }
        private void ProsesWithdraw(long y)
        {
            long uang = Convert.ToInt64(dtBankUC.Rows[choosenAccount][2]);
            if (y > uang)
            {
                MessageBox.Show("Withdrawal Amount Can't be Larger than The Balance");
            }
            else if (y < 1)
            {
                MessageBox.Show("Withdrawal Amount Can't be Less Than 1");
            }
            else if (y <= uang)
            {
                uang = uang - y;
                dtBankUC.Rows[choosenAccount][2] = uang;
                MessageBox.Show("Succesfully Withdraw");
                tb_withdraw.Text = "";
                panel_withdraw.Visible = false;
                panel_mainBalance.Visible = true;
            }
        }

        private void btn_inputWithdraw_Click(object sender, EventArgs e)
        {

            ProsesWithdraw(Convert.ToInt64(tb_withdraw.Text));
            long uang = Convert.ToInt64(dtBankUC.Rows[choosenAccount][2]);
            lb_balanceWith.Text = "Rp " + uang.ToString("N");
            lb_balanceCount.Text = "Rp " + uang.ToString("N");



        }

        private void btn_logOut_Click(object sender, EventArgs e)
        {
            panel_login.Visible = true;
            panel_mainBalance.Visible = false;
            panel_deposit.Visible = false;
            panel_register.Visible = false;
            panel_withdraw.Visible = false;
            btn_logOut.Visible = false;
        }

        private void panel_login_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_withdraw_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_register_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
