﻿namespace AP_W03_Take_Home_UC_Bank
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ucBank = new System.Windows.Forms.Label();
            this.tb_usernameLog = new System.Windows.Forms.TextBox();
            this.lb_passwordLog = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.lb_usernameLog = new System.Windows.Forms.Label();
            this.btn_register = new System.Windows.Forms.Button();
            this.tb_passwordLog = new System.Windows.Forms.TextBox();
            this.panel_login = new System.Windows.Forms.Panel();
            this.panel_register = new System.Windows.Forms.Panel();
            this.tb_passwordReg = new System.Windows.Forms.TextBox();
            this.btn_RegisterReal = new System.Windows.Forms.Button();
            this.lb_usernameReg = new System.Windows.Forms.Label();
            this.lb_passswordReg = new System.Windows.Forms.Label();
            this.tb_usernameReg = new System.Windows.Forms.TextBox();
            this.panel_mainBalance = new System.Windows.Forms.Panel();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.lb_balanceCount = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.btn_logOut = new System.Windows.Forms.Button();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.lb_inputD = new System.Windows.Forms.Label();
            this.tb_inputDeposit = new System.Windows.Forms.TextBox();
            this.btn_inputDeposit = new System.Windows.Forms.Button();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.btn_inputWithdraw = new System.Windows.Forms.Button();
            this.lb_balanceWith = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_withdraw = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_login.SuspendLayout();
            this.panel_register.SuspendLayout();
            this.panel_mainBalance.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_ucBank
            // 
            this.lb_ucBank.AutoSize = true;
            this.lb_ucBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucBank.Location = new System.Drawing.Point(100, 95);
            this.lb_ucBank.Name = "lb_ucBank";
            this.lb_ucBank.Size = new System.Drawing.Size(201, 51);
            this.lb_ucBank.TabIndex = 0;
            this.lb_ucBank.Text = "UC Bank";
            // 
            // tb_usernameLog
            // 
            this.tb_usernameLog.Location = new System.Drawing.Point(121, 25);
            this.tb_usernameLog.Name = "tb_usernameLog";
            this.tb_usernameLog.Size = new System.Drawing.Size(104, 22);
            this.tb_usernameLog.TabIndex = 3;
            // 
            // lb_passwordLog
            // 
            this.lb_passwordLog.AutoSize = true;
            this.lb_passwordLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_passwordLog.Location = new System.Drawing.Point(10, 66);
            this.lb_passwordLog.Name = "lb_passwordLog";
            this.lb_passwordLog.Size = new System.Drawing.Size(88, 20);
            this.lb_passwordLog.TabIndex = 2;
            this.lb_passwordLog.Text = "Password:";
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(64, 111);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(93, 31);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // lb_usernameLog
            // 
            this.lb_usernameLog.AutoSize = true;
            this.lb_usernameLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_usernameLog.Location = new System.Drawing.Point(10, 28);
            this.lb_usernameLog.Name = "lb_usernameLog";
            this.lb_usernameLog.Size = new System.Drawing.Size(91, 20);
            this.lb_usernameLog.TabIndex = 1;
            this.lb_usernameLog.Text = "Username:";
            // 
            // btn_register
            // 
            this.btn_register.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_register.Location = new System.Drawing.Point(64, 148);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(93, 34);
            this.btn_register.TabIndex = 6;
            this.btn_register.Text = "Register";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // tb_passwordLog
            // 
            this.tb_passwordLog.Location = new System.Drawing.Point(121, 64);
            this.tb_passwordLog.Name = "tb_passwordLog";
            this.tb_passwordLog.Size = new System.Drawing.Size(104, 22);
            this.tb_passwordLog.TabIndex = 4;
            // 
            // panel_login
            // 
            this.panel_login.Controls.Add(this.tb_passwordLog);
            this.panel_login.Controls.Add(this.btn_register);
            this.panel_login.Controls.Add(this.lb_usernameLog);
            this.panel_login.Controls.Add(this.btn_login);
            this.panel_login.Controls.Add(this.lb_passwordLog);
            this.panel_login.Controls.Add(this.tb_usernameLog);
            this.panel_login.Location = new System.Drawing.Point(72, 210);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(380, 200);
            this.panel_login.TabIndex = 7;
            this.panel_login.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_login_Paint);
            // 
            // panel_register
            // 
            this.panel_register.Controls.Add(this.tb_passwordReg);
            this.panel_register.Controls.Add(this.btn_RegisterReal);
            this.panel_register.Controls.Add(this.lb_usernameReg);
            this.panel_register.Controls.Add(this.lb_passswordReg);
            this.panel_register.Controls.Add(this.tb_usernameReg);
            this.panel_register.Location = new System.Drawing.Point(72, 210);
            this.panel_register.Name = "panel_register";
            this.panel_register.Size = new System.Drawing.Size(380, 200);
            this.panel_register.TabIndex = 8;
            this.panel_register.Visible = false;
            this.panel_register.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_register_Paint);
            // 
            // tb_passwordReg
            // 
            this.tb_passwordReg.Location = new System.Drawing.Point(121, 58);
            this.tb_passwordReg.Name = "tb_passwordReg";
            this.tb_passwordReg.Size = new System.Drawing.Size(104, 22);
            this.tb_passwordReg.TabIndex = 10;
            // 
            // btn_RegisterReal
            // 
            this.btn_RegisterReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RegisterReal.Location = new System.Drawing.Point(64, 111);
            this.btn_RegisterReal.Name = "btn_RegisterReal";
            this.btn_RegisterReal.Size = new System.Drawing.Size(102, 39);
            this.btn_RegisterReal.TabIndex = 12;
            this.btn_RegisterReal.Text = "Register";
            this.btn_RegisterReal.UseVisualStyleBackColor = true;
            this.btn_RegisterReal.Click += new System.EventHandler(this.btn_RegisterReal_Click);
            // 
            // lb_usernameReg
            // 
            this.lb_usernameReg.AutoSize = true;
            this.lb_usernameReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_usernameReg.Location = new System.Drawing.Point(13, 22);
            this.lb_usernameReg.Name = "lb_usernameReg";
            this.lb_usernameReg.Size = new System.Drawing.Size(91, 20);
            this.lb_usernameReg.TabIndex = 7;
            this.lb_usernameReg.Text = "Username:";
            // 
            // lb_passswordReg
            // 
            this.lb_passswordReg.AutoSize = true;
            this.lb_passswordReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_passswordReg.Location = new System.Drawing.Point(13, 60);
            this.lb_passswordReg.Name = "lb_passswordReg";
            this.lb_passswordReg.Size = new System.Drawing.Size(88, 20);
            this.lb_passswordReg.TabIndex = 8;
            this.lb_passswordReg.Text = "Password:";
            // 
            // tb_usernameReg
            // 
            this.tb_usernameReg.Location = new System.Drawing.Point(121, 19);
            this.tb_usernameReg.Name = "tb_usernameReg";
            this.tb_usernameReg.Size = new System.Drawing.Size(104, 22);
            this.tb_usernameReg.TabIndex = 9;
            // 
            // panel_mainBalance
            // 
            this.panel_mainBalance.Controls.Add(this.btn_withdraw);
            this.panel_mainBalance.Controls.Add(this.btn_deposit);
            this.panel_mainBalance.Controls.Add(this.lb_balanceCount);
            this.panel_mainBalance.Controls.Add(this.lb_balance);
            this.panel_mainBalance.Location = new System.Drawing.Point(72, 210);
            this.panel_mainBalance.Name = "panel_mainBalance";
            this.panel_mainBalance.Size = new System.Drawing.Size(380, 200);
            this.panel_mainBalance.TabIndex = 9;
            this.panel_mainBalance.Visible = false;
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(59, 126);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(99, 37);
            this.btn_withdraw.TabIndex = 3;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(59, 83);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(99, 37);
            this.btn_deposit.TabIndex = 2;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // lb_balanceCount
            // 
            this.lb_balanceCount.AutoSize = true;
            this.lb_balanceCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balanceCount.Location = new System.Drawing.Point(93, 50);
            this.lb_balanceCount.Name = "lb_balanceCount";
            this.lb_balanceCount.Size = new System.Drawing.Size(55, 16);
            this.lb_balanceCount.TabIndex = 1;
            this.lb_balanceCount.Text = "Rp0,00";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance.Location = new System.Drawing.Point(19, 47);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(80, 20);
            this.lb_balance.TabIndex = 0;
            this.lb_balance.Text = "Balance: ";
            // 
            // btn_logOut
            // 
            this.btn_logOut.Location = new System.Drawing.Point(305, 103);
            this.btn_logOut.Name = "btn_logOut";
            this.btn_logOut.Size = new System.Drawing.Size(88, 42);
            this.btn_logOut.TabIndex = 10;
            this.btn_logOut.Text = "Log Out";
            this.btn_logOut.UseVisualStyleBackColor = true;
            this.btn_logOut.Visible = false;
            this.btn_logOut.Click += new System.EventHandler(this.btn_logOut_Click);
            // 
            // panel_deposit
            // 
            this.panel_deposit.Controls.Add(this.btn_inputDeposit);
            this.panel_deposit.Controls.Add(this.tb_inputDeposit);
            this.panel_deposit.Controls.Add(this.lb_inputD);
            this.panel_deposit.Location = new System.Drawing.Point(72, 210);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(380, 200);
            this.panel_deposit.TabIndex = 7;
            this.panel_deposit.Visible = false;
            // 
            // lb_inputD
            // 
            this.lb_inputD.AutoSize = true;
            this.lb_inputD.Location = new System.Drawing.Point(52, 65);
            this.lb_inputD.Name = "lb_inputD";
            this.lb_inputD.Size = new System.Drawing.Size(136, 16);
            this.lb_inputD.TabIndex = 0;
            this.lb_inputD.Text = "Input Deposit Amount:";
            // 
            // tb_inputDeposit
            // 
            this.tb_inputDeposit.Location = new System.Drawing.Point(55, 90);
            this.tb_inputDeposit.Name = "tb_inputDeposit";
            this.tb_inputDeposit.Size = new System.Drawing.Size(133, 22);
            this.tb_inputDeposit.TabIndex = 1;
            // 
            // btn_inputDeposit
            // 
            this.btn_inputDeposit.Location = new System.Drawing.Point(69, 122);
            this.btn_inputDeposit.Name = "btn_inputDeposit";
            this.btn_inputDeposit.Size = new System.Drawing.Size(100, 35);
            this.btn_inputDeposit.TabIndex = 2;
            this.btn_inputDeposit.Text = "Deposit";
            this.btn_inputDeposit.UseVisualStyleBackColor = true;
            this.btn_inputDeposit.Click += new System.EventHandler(this.btn_inputDeposit_Click);
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.label1);
            this.panel_withdraw.Controls.Add(this.tb_withdraw);
            this.panel_withdraw.Controls.Add(this.lb_balanceWith);
            this.panel_withdraw.Controls.Add(this.label2);
            this.panel_withdraw.Controls.Add(this.btn_inputWithdraw);
            this.panel_withdraw.Location = new System.Drawing.Point(72, 210);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(380, 200);
            this.panel_withdraw.TabIndex = 11;
            this.panel_withdraw.Visible = false;
            this.panel_withdraw.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_withdraw_Paint);
            // 
            // btn_inputWithdraw
            // 
            this.btn_inputWithdraw.Location = new System.Drawing.Point(69, 143);
            this.btn_inputWithdraw.Name = "btn_inputWithdraw";
            this.btn_inputWithdraw.Size = new System.Drawing.Size(100, 35);
            this.btn_inputWithdraw.TabIndex = 0;
            this.btn_inputWithdraw.Text = "Withdraw";
            this.btn_inputWithdraw.UseVisualStyleBackColor = true;
            this.btn_inputWithdraw.Click += new System.EventHandler(this.btn_inputWithdraw_Click);
            // 
            // lb_balanceWith
            // 
            this.lb_balanceWith.AutoSize = true;
            this.lb_balanceWith.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balanceWith.Location = new System.Drawing.Point(122, 58);
            this.lb_balanceWith.Name = "lb_balanceWith";
            this.lb_balanceWith.Size = new System.Drawing.Size(55, 16);
            this.lb_balanceWith.TabIndex = 3;
            this.lb_balanceWith.Text = "Rp0,00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Balance: ";
            // 
            // tb_withdraw
            // 
            this.tb_withdraw.Location = new System.Drawing.Point(54, 115);
            this.tb_withdraw.Name = "tb_withdraw";
            this.tb_withdraw.Size = new System.Drawing.Size(123, 22);
            this.tb_withdraw.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Input Withdrawal Amount:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 450);
            this.Controls.Add(this.panel_withdraw);
            this.Controls.Add(this.panel_deposit);
            this.Controls.Add(this.panel_login);
            this.Controls.Add(this.panel_register);
            this.Controls.Add(this.btn_logOut);
            this.Controls.Add(this.panel_mainBalance);
            this.Controls.Add(this.lb_ucBank);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.panel_register.ResumeLayout(false);
            this.panel_register.PerformLayout();
            this.panel_mainBalance.ResumeLayout(false);
            this.panel_mainBalance.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_ucBank;
        private System.Windows.Forms.TextBox tb_usernameLog;
        private System.Windows.Forms.Label lb_passwordLog;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lb_usernameLog;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.TextBox tb_passwordLog;
        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Panel panel_register;
        private System.Windows.Forms.TextBox tb_passwordReg;
        private System.Windows.Forms.Button btn_RegisterReal;
        private System.Windows.Forms.Label lb_usernameReg;
        private System.Windows.Forms.Label lb_passswordReg;
        private System.Windows.Forms.TextBox tb_usernameReg;
        private System.Windows.Forms.Panel panel_mainBalance;
        private System.Windows.Forms.Label lb_balanceCount;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Button btn_logOut;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.Label lb_inputD;
        private System.Windows.Forms.TextBox tb_inputDeposit;
        private System.Windows.Forms.Button btn_inputDeposit;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.Button btn_inputWithdraw;
        private System.Windows.Forms.Label lb_balanceWith;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_withdraw;
    }
}

