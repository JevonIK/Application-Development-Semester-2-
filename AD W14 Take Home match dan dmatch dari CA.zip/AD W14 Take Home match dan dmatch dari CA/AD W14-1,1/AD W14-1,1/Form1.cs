﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace AD_W14_1_1
{
    // Take Home W14 - Jevon
    public partial class FORM_pertama : Form
    {

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlAdapter;
        string sqlQuery;

        DataTable dt = new DataTable();
        DataTable dtteam = new DataTable();
        DataTable dtaway = new DataTable();
        DataTable player = new DataTable();
        DataTable dmatch = new DataTable();

        string idhome;
        string idaway;
        string idteam;

        int indeksBaris;

        public FORM_pertama()
        {
            InitializeComponent();
        }

        private void FORM_pertama_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");

            dmatch = new DataTable();
            dmatch.Columns.Add("match_id");
            dmatch.Columns.Add("minute");
            dmatch.Columns.Add("team_id");
            dmatch.Columns.Add("player_id");
            dmatch.Columns.Add("type");
            dmatch.Columns.Add("delete");

            dtteam = new DataTable();
            dtaway = new DataTable();

            sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=Universitasciputra0;database=premier_league");

            sqlQuery = "select team_id, team_name from team t;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);

            sqlAdapter.Fill(dtteam);
            sqlAdapter.Fill(dtaway);
            cb_teamHome.DataSource = dtteam;
            cb_teamHome.DisplayMember = "team_name";
            cb_teamHome.ValueMember = "team_id";
            cb_teamHome.SelectedIndex = -1;

            cb_teamAway.DataSource = dtaway;
            cb_teamAway.DisplayMember = "team_name";
            cb_teamAway.ValueMember = "team_id";
            cb_teamAway.SelectedIndex = -1;
        }

        private void dateTimePicker_matchDate_ValueChanged(object sender, EventArgs e)
        {
            string year = dateTimePicker_matchDate.Value.Year.ToString();

            sqlQuery = $"select count(match_id) from `match` where match_id like '{year}%';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);

            DataTable dtCount = new DataTable();
            sqlAdapter.Fill(dtCount);
     
            if (Convert.ToInt32(dtCount.Rows[0][0]) < 10)
            {
                tb_matchID.Text = $"{year}00{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }

            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 10 && Convert.ToInt32(dtCount.Rows[0][0]) < 100)
            {
                tb_matchID.Text = $"{year}0{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }

            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 100)
            {
                tb_matchID.Text = $"{year}{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
          
        }

        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamHome.SelectedIndex == -1 && cb_teamAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (cb_teamAway.SelectedIndex == cb_teamHome.SelectedIndex)
                {
                    MessageBox.Show("Team tidak boleh sama!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cb_teamHome.SelectedIndex = -1;
                    cb_teamAway.SelectedIndex = -1;
                }
                else
                {
                    cb_team.Items.Clear();
                    idhome = Convert.ToString(cb_teamHome.SelectedValue);
                    idaway = Convert.ToString(cb_teamAway.SelectedValue);
                    cb_team.Items.Add(cb_teamHome.Text);
                    cb_team.Items.Add(cb_teamAway.Text);
                }
            }
        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamHome.SelectedIndex == -1 && cb_teamAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (cb_teamAway.SelectedIndex == cb_teamHome.SelectedIndex)
                {
                    MessageBox.Show("Team tidak boleh sama!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cb_teamHome.SelectedIndex = -1;
                    cb_teamAway.SelectedIndex = -1;
                }
                else
                {
                    cb_team.Items.Clear();
                    idhome = Convert.ToString(cb_teamHome.SelectedValue);
                    idaway = Convert.ToString(cb_teamAway.SelectedValue);
                    cb_team.Items.Add(cb_teamHome.Text);
                    cb_team.Items.Add(cb_teamAway.Text);
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            player = new DataTable();
            if (cb_team.SelectedIndex == 0)
            {
                idteam = idhome;
            }
            if (cb_team.SelectedIndex == 1)
            {
                idteam = idaway;
            }

            sqlQuery = $"select player_id, player_name from player where team_id like '%{idteam}%';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_matchID.Text == "" || cb_teamHome.Text == "" || cb_teamAway.Text == "" || tb_minute.Text == "" || cb_team.Text == "" || cb_player.Text == "" || cb_type.Text == "")
            {
                MessageBox.Show("Semua Field Harus Terisi!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                dt.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
                dgv_view.DataSource = dt;
                dmatch.Rows.Add(tb_matchID.Text, tb_minute.Text, idteam, cb_player.SelectedValue, cb_type.Text, 0);
            }

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            dt.Rows.RemoveAt(indeksBaris);
            dgv_view.DataSource = dt;
            dmatch.Rows.RemoveAt(indeksBaris);
        }

        
        private void dgv_view_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indeksBaris = e.RowIndex;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {

            //try
            //{

            //    bool tanggalBenar = false;
            //    if (dateTimePicker_matchDate.Value.Year == 2016 && dateTimePicker_matchDate.Value.Month == 2 && dateTimePicker_matchDate.Value.Day >= 14)
            //    {
            //        tanggalBenar = true;
            //    }
            //    else if(dateTimePicker_matchDate.Value.Year == 2016 && dateTimePicker_matchDate.Value.Month > 2)
            //    {
            //        tanggalBenar = true;
            //    }           
            //    else if (dateTimePicker_matchDate.Value.Year > 2016)
            //    {
            //        tanggalBenar = true;
            //    }
            //    else
            //    {
            //        tanggalBenar = false;
            //    }


            //    if (tanggalBenar)
            //    {
            //        sqlConnect.Open();

            //        for (int i = 0; i < dmatch.Rows.Count; i++)
            //        {
            //            sqlQuery = $"insert into dmatch values ({dmatch.Rows[i][0]}, {dmatch.Rows[i][1]}, '{dmatch.Rows[i][2]}', '{dmatch.Rows[i][3]}', '{dmatch.Rows[i][4]}', {dmatch.Rows[i][5]});";
            //            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            //            sqlCommand.ExecuteNonQuery();
            //        }

            //        int scorehome = 0;
            //        int scoreaway = 0;
            //        for (int i = 0; i < dt.Rows.Count; i++)
            //        {
            //            if (dt.Rows[i][1].ToString() == cb_teamHome.Text)
            //            {
            //                if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
            //                {
            //                    scorehome++;
            //                }
            //                else if (dt.Rows[i][3].ToString() == "GW")
            //                {
            //                    scoreaway++;
            //                }
            //            }
            //            else
            //            {
            //                if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
            //                {
            //                    scoreaway++;
            //                }
            //                else if (dt.Rows[i][3].ToString() == "GW")
            //                {
            //                    scorehome++;
            //                }
            //            }
            //        }

            //        sqlQuery = $"insert into `match` values ('{tb_matchID.Text}', '{dateTimePicker_matchDate.Value.ToString("yyyy-MM-dd")}', '{idhome}', '{idaway}', {scorehome}, {scoreaway}, 'M002', 0);";
            //        sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            //        sqlCommand.ExecuteNonQuery();

            //        sqlConnect.Close();



            //    }
            //    else if (tanggalBenar == false)
            //    {
            //        MessageBox.Show("Error tanggal tidak valid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);

            //}


            bool tanggalBenar = false;
            if (dateTimePicker_matchDate.Value.Year == 2016 && dateTimePicker_matchDate.Value.Month == 2 && dateTimePicker_matchDate.Value.Day >= 14)
            {
                tanggalBenar = true;
            }
            else if (dateTimePicker_matchDate.Value.Year == 2016 && dateTimePicker_matchDate.Value.Month > 2)
            {
                tanggalBenar = true;
            }
            else if (dateTimePicker_matchDate.Value.Year > 2016)
            {
                tanggalBenar = true;
            }
            else
            {
                tanggalBenar = false;
            }

            if (tanggalBenar)
            {
                try
                {
                    sqlConnect.Open();
                    for (int i = 0; i < dmatch.Rows.Count; i++)
                    {
                        sqlQuery = $"insert into dmatch values ({dmatch.Rows[i][0]}, {dmatch.Rows[i][1]}, '{dmatch.Rows[i][2]}', '{dmatch.Rows[i][3]}', '{dmatch.Rows[i][4]}', {dmatch.Rows[i][5]});";
                        sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                        sqlCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                int scorehome = 0;
                int scoreaway = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][1].ToString() == cb_teamHome.Text)
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            scorehome++;
                        }
                        else if (dt.Rows[i][3].ToString() == "GW")
                        {
                            scoreaway++;
                        }
                    }
                    else
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            scoreaway++;
                        }
                        else if (dt.Rows[i][3].ToString() == "GW")
                        {
                            scorehome++;
                        }
                    }
                }
                try
                {
                    sqlQuery = $"insert into `match` values ('{tb_matchID.Text}', '{dateTimePicker_matchDate.Value.ToString("yyyy-MM-dd")}', '{idhome}', '{idaway}', {scorehome}, {scoreaway}, 'M002', 0);";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                dt.Clear();
                dmatch.Clear();
                dgv_view.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Tanggal tidak valid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // KALAU ERROR JGN LUPA UPDATE MATCH ID NYA JADI USER HARUS INPUT TANGGAL LAGI (JGN DIBIARIN SAMA)
            // KALAU KATANYA DUPLICATE ENTRY EMANG GITU KARENA PAKAI TRY CATCH TP DATANYA TTP MASUK DI DATABASE

        }
    }
}
