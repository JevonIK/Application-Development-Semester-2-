﻿namespace AD_W14_1_1
{
    partial class FORM_pertama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_view = new System.Windows.Forms.DataGridView();
            this.lb_1 = new System.Windows.Forms.Label();
            this.lb_2 = new System.Windows.Forms.Label();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.btn_insert = new System.Windows.Forms.Button();
            this.lb_3 = new System.Windows.Forms.Label();
            this.lb_4 = new System.Windows.Forms.Label();
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_matchDate = new System.Windows.Forms.DateTimePicker();
            this.lb_5 = new System.Windows.Forms.Label();
            this.lb_6 = new System.Windows.Forms.Label();
            this.lb_7 = new System.Windows.Forms.Label();
            this.lb_8 = new System.Windows.Forms.Label();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_view)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_view
            // 
            this.dgv_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_view.Location = new System.Drawing.Point(103, 194);
            this.dgv_view.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgv_view.Name = "dgv_view";
            this.dgv_view.RowHeadersWidth = 82;
            this.dgv_view.RowTemplate.Height = 33;
            this.dgv_view.Size = new System.Drawing.Size(706, 298);
            this.dgv_view.TabIndex = 0;
            this.dgv_view.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_view_CellClick);
            // 
            // lb_1
            // 
            this.lb_1.AutoSize = true;
            this.lb_1.Location = new System.Drawing.Point(99, 69);
            this.lb_1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_1.Name = "lb_1";
            this.lb_1.Size = new System.Drawing.Size(59, 16);
            this.lb_1.TabIndex = 1;
            this.lb_1.Text = "Match ID";
            // 
            // lb_2
            // 
            this.lb_2.AutoSize = true;
            this.lb_2.Location = new System.Drawing.Point(99, 119);
            this.lb_2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_2.Name = "lb_2";
            this.lb_2.Size = new System.Drawing.Size(83, 16);
            this.lb_2.TabIndex = 2;
            this.lb_2.Text = "Team Home";
            // 
            // tb_matchID
            // 
            this.tb_matchID.Location = new System.Drawing.Point(228, 65);
            this.tb_matchID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.ReadOnly = true;
            this.tb_matchID.Size = new System.Drawing.Size(152, 22);
            this.tb_matchID.TabIndex = 3;
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(532, 527);
            this.btn_insert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(277, 35);
            this.btn_insert.TabIndex = 5;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // lb_3
            // 
            this.lb_3.AutoSize = true;
            this.lb_3.Location = new System.Drawing.Point(727, 68);
            this.lb_3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_3.Name = "lb_3";
            this.lb_3.Size = new System.Drawing.Size(75, 16);
            this.lb_3.TabIndex = 6;
            this.lb_3.Text = "Match Date";
            // 
            // lb_4
            // 
            this.lb_4.AutoSize = true;
            this.lb_4.Location = new System.Drawing.Point(727, 119);
            this.lb_4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_4.Name = "lb_4";
            this.lb_4.Size = new System.Drawing.Size(79, 16);
            this.lb_4.TabIndex = 7;
            this.lb_4.Text = "Team Away";
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(228, 113);
            this.cb_teamHome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(152, 24);
            this.cb_teamHome.TabIndex = 8;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(853, 117);
            this.cb_teamAway.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(152, 24);
            this.cb_teamAway.TabIndex = 9;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // dateTimePicker_matchDate
            // 
            this.dateTimePicker_matchDate.Location = new System.Drawing.Point(853, 65);
            this.dateTimePicker_matchDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePicker_matchDate.Name = "dateTimePicker_matchDate";
            this.dateTimePicker_matchDate.Size = new System.Drawing.Size(301, 22);
            this.dateTimePicker_matchDate.TabIndex = 10;
            this.dateTimePicker_matchDate.ValueChanged += new System.EventHandler(this.dateTimePicker_matchDate_ValueChanged);
            // 
            // lb_5
            // 
            this.lb_5.AutoSize = true;
            this.lb_5.Location = new System.Drawing.Point(862, 221);
            this.lb_5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_5.Name = "lb_5";
            this.lb_5.Size = new System.Drawing.Size(46, 16);
            this.lb_5.TabIndex = 11;
            this.lb_5.Text = "Minute";
            // 
            // lb_6
            // 
            this.lb_6.AutoSize = true;
            this.lb_6.Location = new System.Drawing.Point(862, 280);
            this.lb_6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_6.Name = "lb_6";
            this.lb_6.Size = new System.Drawing.Size(43, 16);
            this.lb_6.TabIndex = 12;
            this.lb_6.Text = "Team";
            // 
            // lb_7
            // 
            this.lb_7.AutoSize = true;
            this.lb_7.Location = new System.Drawing.Point(862, 339);
            this.lb_7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_7.Name = "lb_7";
            this.lb_7.Size = new System.Drawing.Size(46, 16);
            this.lb_7.TabIndex = 13;
            this.lb_7.Text = "Player";
            // 
            // lb_8
            // 
            this.lb_8.AutoSize = true;
            this.lb_8.Location = new System.Drawing.Point(862, 391);
            this.lb_8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_8.Name = "lb_8";
            this.lb_8.Size = new System.Drawing.Size(39, 16);
            this.lb_8.TabIndex = 14;
            this.lb_8.Text = "Type";
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(952, 220);
            this.tb_minute.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(152, 22);
            this.tb_minute.TabIndex = 15;
            // 
            // cb_team
            // 
            this.cb_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(952, 278);
            this.cb_team.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(152, 24);
            this.cb_team.TabIndex = 16;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_player
            // 
            this.cb_player.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(952, 337);
            this.cb_player.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(152, 24);
            this.cb_player.TabIndex = 17;
            // 
            // cb_type
            // 
            this.cb_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Items.AddRange(new object[] {
            "GO",
            "GP",
            "GW",
            "CR",
            "CY",
            "PM"});
            this.cb_type.Location = new System.Drawing.Point(952, 391);
            this.cb_type.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(152, 24);
            this.cb_type.TabIndex = 18;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(891, 448);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(94, 31);
            this.btn_add.TabIndex = 19;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1009, 448);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(94, 31);
            this.btn_delete.TabIndex = 20;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // FORM_pertama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 675);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.lb_8);
            this.Controls.Add(this.lb_7);
            this.Controls.Add(this.lb_6);
            this.Controls.Add(this.lb_5);
            this.Controls.Add(this.dateTimePicker_matchDate);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.cb_teamHome);
            this.Controls.Add(this.lb_4);
            this.Controls.Add(this.lb_3);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.lb_2);
            this.Controls.Add(this.lb_1);
            this.Controls.Add(this.dgv_view);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FORM_pertama";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FORM_pertama_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_view)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_view;
        private System.Windows.Forms.Label lb_1;
        private System.Windows.Forms.Label lb_2;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.Label lb_3;
        private System.Windows.Forms.Label lb_4;
        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.DateTimePicker dateTimePicker_matchDate;
        private System.Windows.Forms.Label lb_5;
        private System.Windows.Forms.Label lb_6;
        private System.Windows.Forms.Label lb_7;
        private System.Windows.Forms.Label lb_8;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
    }
}

